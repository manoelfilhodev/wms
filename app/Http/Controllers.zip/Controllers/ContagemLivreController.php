<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ContagemLivreController extends Controller
{
    public function form()
    {
        return view('contagem.contagem-livre');
    }

public function salvar(Request $request)
{
    DB::table('_tb_contagem_livre')->insert([
        'ficha' => $request->ficha,
        'sku' => $request->sku,
        'quantidade' => $request->quantidade,
        'contado_por' => Auth::id()
    ]);

    $mensagem = "Contagem registrada com sucesso para o SKU {$request->sku}, ficha {$request->ficha}, com {$request->quantidade} unidades.";

    $contagens = DB::table('_tb_contagem_livre as c')
        ->join('_tb_usuarios as u', 'c.contado_por', '=', 'u.id_user')
        ->select('c.ficha', 'c.sku', 'c.quantidade', 'u.nome as usuario', 'c.data_hora')
        ->orderByDesc('c.data_hora')
        ->limit(50)
        ->get();

    return view('contagem.contagem-livre', compact('mensagem', 'contagens'));
}




public function listar()
{
    $contagens = DB::table('_tb_contagem_livre as c')
        ->join('_tb_usuarios as u', 'c.contado_por', '=', 'u.id_user')
        ->select('c.ficha', 'c.sku', 'c.quantidade', 'u.nome as usuario', 'c.data_hora')
        ->orderByDesc('c.data_hora')
        ->get();

    return view('contagem.listar-contagens', compact('contagens'));
}




}
