<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <title>Login | WMS 4.0</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Sistema de Gestão de Armazém" name="description" />
    <meta content="Systex Sistemas Inteligentes" name="Manoel Filho" />
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
    <link href="<?php echo e(asset('images/logo-sem-nome.png')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/app-creative.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />
    <link href="<?php echo e(asset('assets/css/app-creative-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style" />
</head>
<body class="authentication-bg" data-layout-config='{"darkMode":false}'>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home3/systex91/public_html/wms/resources/views/layouts/auth.blade.php ENDPATH**/ ?>