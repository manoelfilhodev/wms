

<?php $__env->startSection('title', 'Relatório - Contagem de Paletes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="card shadow-sm">
        <div class="card-body">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">
                    <i class="uil uil-box text-warning"></i> Relatório de Contagem de Paletes
                </h5>
                 
                <div class="d-flex gap-2">
                    <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->tipo === 'admin'): ?>
                    <a href="<?php echo e(route('contagem.paletes.excel')); ?>" class="btn btn-success btn-sm">
                        <i class="uil uil-file-exclamation-alt"></i> Excel
                    </a>
                     <?php endif; ?>
                <?php endif; ?>
                    <!--<a href="<?php echo e(route('contagem.paletes.pdf')); ?>" class="btn btn-danger btn-sm">-->
                    <!--    <i class="uil uil-file-pdf-alt"></i> PDF-->
                    <!--</a>-->
                    
                </div>
               
            </div>

            <form method="GET" class="row g-2 mb-3">
                <div class="col-md-4">
                    <label class="form-label">Tipo de Palete</label>
                    <input type="text" name="tipo_palete" class="form-control" placeholder="Ex: PBR, EURO..." value="<?php echo e(request('tipo_palete')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Data Início</label>
                    <input type="date" name="data_inicio" class="form-control" value="<?php echo e(request('data_inicio')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Data Fim</label>
                    <input type="date" name="data_fim" class="form-control" value="<?php echo e(request('data_fim')); ?>">
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-secondary w-100">
                        <i class="uil uil-filter"></i> Filtrar
                    </button>
                </div>
            </form>
            <div class="row mt-2 mb-2">
                <div class="col-12">
                    <a href="<?php echo e(route('contagem.paletes.create')); ?>" class="btn btn-primary btn-sm w-100">
                        <i class="uil uil-plus"></i> Nova Contagem
                    </a>
                </div>
                
            </div>
            

            <?php if($contagens->count()): ?>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle text-center">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Tipo de Palete</th>
                                <th>Quantidade</th>
                                <th>Responsável</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->tipo_palete); ?></td>
                                    <td><?php echo e($item->quantidade); ?></td>
                                    <td><?php echo e($item->usuario->nome ?? 'N/A'); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->data_contagem)->format('d/m/Y H:i')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
            <?php else: ?>
                <div class="alert alert-warning mt-3">
                    Nenhuma contagem encontrada para os filtros aplicados.
                </div>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/contagem/paletes/index.blade.php ENDPATH**/ ?>