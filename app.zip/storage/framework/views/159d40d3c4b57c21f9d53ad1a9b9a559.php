
<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Pedidos Pendentes</h4>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Número</th>
                <th>FO</th>
                <th>Data</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($pedido->numero_pedido); ?></td>
                    <td><?php echo e($pedido->itens->first()->fo ?? 'N/D'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($pedido->created_at)->format('d/m/Y H:i')); ?></td>
                    <td><span class="badge bg-secondary">Pendente</span></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('separacoes.iniciar', $pedido->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-warning">Iniciar Separação</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">Nenhum pedido pendente encontrado.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/pedidos/index.blade.php ENDPATH**/ ?>