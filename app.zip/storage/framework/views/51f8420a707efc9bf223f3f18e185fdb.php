

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="mb-0">Lista de Usuários</h4>
            <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success">
    <i class="mdi mdi-account-plus-outline me-1"></i> Novo Usuário
</a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Nome</th>
                                <th>Login</th>
                                <th>Unidade</th>
                                <th>Status</th>
                                <th>Nível</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($usuario->nome); ?></td>
                                    <td><?php echo e(mb_strtolower($usuario->email)); ?></td>
                                    <td><?php echo e($usuario->unidade_id); ?></td>
                                    <td>
                                        <?php if($usuario->status == 'ativo'): ?>
                                            <span class="badge bg-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($usuario->tipo); ?></td>
                                    <td>
    <a href="<?php echo e(route('usuarios.edit', $usuario->id_user)); ?>" class="btn btn-icon btn-sm btn-primary me-1" title="Editar">
        <i class="mdi mdi-pencil-outline"></i>
    </a>

    <form action="<?php echo e(route('usuarios.destroy', $usuario->id_user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Deseja realmente excluir este usuário?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-icon btn-sm btn-danger" title="Excluir">
            <i class="mdi mdi-trash-can-outline"></i>
        </button>
    </form>
</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Nenhum usuário encontrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/usuarios/index.blade.php ENDPATH**/ ?>