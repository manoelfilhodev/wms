

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Pedido <?php echo e($pedido->numero_pedido); ?> - FO: <?php echo e($pedido->itens->first()->fo ?? 'N/D'); ?></h4>


    <p><strong>Status:</strong> <?php echo e(ucfirst($pedido->status)); ?></p>
    <p><strong>Unidade:</strong> <?php echo e($pedido->unidade_id); ?></p>

    <h5>Itens do Pedido:</h5>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>SKU</th>
                <th>Qtde</th>
                <th>Centro</th>
                <th>FO</th>
                <th>Conferido</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pedido->itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->sku); ?></td>
                    <td><?php echo e($item->quantidade); ?></td>
                    <td><?php echo e($item->centro); ?></td>
                    <td><?php echo e($item->fo); ?></td>
                    <td><?php echo $item->conferido ? '✅' : '❌'; ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/pedidos/show.blade.php ENDPATH**/ ?>