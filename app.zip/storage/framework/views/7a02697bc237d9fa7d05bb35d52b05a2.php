

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">Relatório de Separações</h4>
        <div>
            <a href="<?php echo e(route('relatorios.separacoes.excel', request()->query())); ?>" class="btn btn-success btn-sm me-2">
                <i class="mdi mdi-file-excel"></i> Exportar Excel
            </a>
            <a href="<?php echo e(route('relatorios.separacoes.pdf', request()->query())); ?>" class="btn btn-danger btn-sm">
                <i class="mdi mdi-file-pdf"></i> Exportar PDF
            </a>
        </div>
    </div>

    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-3">
            <label>Data Início</label>
            <input type="date" name="data_inicio" class="form-control" value="<?php echo e(request('data_inicio')); ?>">
        </div>
        <div class="col-md-3">
            <label>Data Fim</label>
            <input type="date" name="data_fim" class="form-control" value="<?php echo e(request('data_fim')); ?>">
        </div>
        <div class="col-md-3">
            <label>Unidade</label>
            <select name="unidade_id" class="form-control">
                <option value="">Todas</option>
                <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($unidade->id); ?>" <?php echo e(request('unidade_id') == $unidade->id ? 'selected' : ''); ?>>
                        <?php echo e($unidade->nome); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label>Usuário</label>
            <select name="usuario_id" class="form-control">
                <option value="">Todos</option>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($usuario->id_user); ?>" <?php echo e(request('usuario_id') == $usuario->id_user ? 'selected' : ''); ?>>
                        <?php echo e(mb_strtoupper($usuario->nome)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-12 align-self-end">
            <button class="btn btn-primary w-100">
                <i class="mdi mdi-filter"></i> Filtrar
            </button>
        </div>
    </form>

    <!--<div class="card mb-4">-->
    <!--    <div class="card-body">-->
    <!--        <canvas id="graficoSeparacoes" height="100"></canvas>-->
    <!--    </div>-->
    <!--</div>-->

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="table-light">
                <tr>
                    <th>Data</th>
                    <th>Usuário</th>
                    <th>Unidade</th>
                    <th>SKU</th>
                    <th>Posição</th>
                    <th>Quantidade</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $separacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(date('d/m/Y', strtotime($item->data_separacao))); ?></td>
                        <td><?php echo e(mb_strtoupper($item->usuario_nome)); ?></td>
                        <td><?php echo e($item->unidade_nome); ?></td>
                        <td><?php echo e(mb_strtoupper($item->sku)); ?></td>
                        <td><?php echo e(mb_strtoupper($item->endereco)); ?></td>
                        <td><?php echo e($item->quantidade); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">Nenhum dado encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

 
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('graficoSeparacoes').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($grafico->pluck('nome')); ?>,
            datasets: [{
                label: 'Total de Separações',
                data: <?php echo json_encode($grafico->pluck('total')); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/relatorios/separacoes.blade.php ENDPATH**/ ?>