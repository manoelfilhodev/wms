

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
   <?php echo $__env->make('partials.breadcrumb-auto', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
         
        <h4 class="mb-0">Logs de Usuários</h4>
        
        <div>
            
            <a href="<?php echo e(route('logs.export.excel', request()->query())); ?>" class="btn btn-success btn-sm me-2">
                <i class="mdi mdi-file-excel"></i> Exportar Excel
            </a>
            <a href="<?php echo e(route('logs.export.pdf', request()->query())); ?>" class="btn btn-danger btn-sm">
                <i class="mdi mdi-file-pdf"></i> Exportar PDF
            </a>
        </div>
    </div>

    <form method="GET" class="row g-2 mb-3">
        <div class="col-md-3">
            <input type="text" name="usuario" class="form-control" placeholder="Nome do usuário" value="<?php echo e(request('usuario')); ?>">
        </div>
        <div class="col-md-3">
            <input type="text" name="acao" class="form-control" placeholder="Ação realizada" value="<?php echo e(request('acao')); ?>">
        </div>
        <div class="col-md-3">
            <input type="date" name="data" class="form-control" value="<?php echo e(request('data')); ?>">
        </div>
        <div class="col-md-3">
            <select name="unidade" class="form-control">
                <option value="">Todas as unidades</option>
                <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($unidade->nome); ?>" <?php echo e(request('unidade') == $unidade->nome ? 'selected' : ''); ?>>
                        <?php echo e($unidade->nome); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary w-100">
                <i class="mdi mdi-filter"></i> Filtrar
            </button>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Usuário</th>
                    <th>Unidade</th>
                    <th>Ação</th>
                    <th>Dados</th>
                    <th>IP</th>
                    <th>Navegador</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr style="font-size: 12px">
                        <td><?php echo e(mb_strtoupper($log->usuario->nome ?? '---')); ?></td>
                        <td><?php echo e($log->unidade->nome ?? '---'); ?></td>
                        <td><?php echo e(mb_strtoupper($log->acao)); ?></td>
                        <td style="max-width: 300px; word-break: break-word;"><?php echo e($log->dados); ?></td>
                        <td><?php echo e($log->ip_address); ?></td>
                        <td style="max-width: 200px;"><?php echo e($log->navegador); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('d/m/Y H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Nenhum log encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/logs/index.blade.php ENDPATH**/ ?>