
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-4">Central de Separação</h4>

    <div class="row">
        <!-- Sempre visível -->
        <div class="col-md-4 mb-3">
            <a href="<?php echo e(route('pedidos.index')); ?>" class="card text-center text-decoration-none text-dark shadow-sm h-100">
                <div class="card-body">
                    <div class="position-relative">
                        <i class="mdi mdi-play-circle-outline mdi-48px text-warning"></i>
                    
                        <?php if($pedidosPendentes > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?php echo e($pedidosPendentes); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <h5 class="mt-2">Pedidos Pendentes</h5>
                </div>
            </a>
        </div>
        <div class="col-md-4 mb-3">
            <a href="<?php echo e(route('separacoes.index')); ?>" class="card text-center text-decoration-none text-dark shadow-sm h-100">
                <div class="card-body">
                    <i class="mdi mdi-format-list-bulleted mdi-48px text-info"></i>
                    <h5 class="mt-2">Separações em Andamento</h5>
                </div>
            </a>
        </div>
        <div class="col-md-4 mb-3">
    <a href="<?php echo e(route('separacoes.linha.manual')); ?>" class="card text-center text-decoration-none text-dark shadow-sm h-100">
        <div class="card-body">
            <i class="mdi mdi-factory mdi-48px text-success"></i>
            <h5 class="mt-2">Separação Linha</h5>
        </div>
    </a>
</div>




        

        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->tipo === 'admin'): ?>
                <div class="col-md-4 mb-3">
                    <a href="<?php echo e(route('pedidos.create')); ?>" class="card text-center text-decoration-none text-dark shadow-sm h-100">
                        <div class="card-body">
                            <i class="mdi mdi-playlist-plus mdi-48px text-success"></i>
                            <h5 class="mt-2">Inserir Novo Pedido</h5>
                        </div>
                    </a>
                </div>
                

                <div class="col-md-4 mb-3">
                    <a href="<?php echo e(route('relatorios.separacoes')); ?>" class="card text-center text-decoration-none text-dark shadow-sm h-100">
                        <div class="card-body">
                            <i class="mdi mdi-chart-bar mdi-48px text-primary"></i>
                            <h5 class="mt-2">Relatório de Separações</h5>
                        </div>
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/index.blade.php ENDPATH**/ ?>