

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Painel de Recebimento - Notas Fiscais</h4>

    <a href="<?php echo e(route('setores.recebimento.create')); ?>" class="btn btn-primary mb-3">Iniciar Recebimento</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Iniciar</th>
                <th>NF</th>
                <th>Fornecedor</th>
                <th>Data</th>
                <th>Status</th>
                <th>Progresso</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $recebimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recebimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $totalItens = $recebimento->itens->count();
                $armazenados = $recebimento->itens->where('status', 'armazenado')->count();
                $percentual = $totalItens > 0 ? round(($armazenados / $totalItens) * 100) : 0;

                $temDivergencia = DB::table('_tb_recebimento_itens')
                    ->where('recebimento_id', $recebimento->id)
                    ->where('divergente', 1)
                    ->exists();

                $temAvaria = DB::table('_tb_recebimento_itens')
                    ->where('recebimento_id', $recebimento->id)
                    ->where('avariado', 1)
                    ->exists();

                $itensTotal = $recebimento->itens->count();
                $itensConferidos = $recebimento->itens->where('status', 'conferido')->count();
                $userTipo = Auth::user()->tipo ?? 'operador';
                $nivel = strtolower(Auth::user()->nivel);
            ?>
            <tr>
                <td>
             
                        <span class="text-success">✔</span>
                   
                </td>
                <td><?php echo e($recebimento->nota_fiscal); ?></td>
                <td><?php echo e($recebimento->fornecedor); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($recebimento->data_recebimento)->format('d/m/Y')); ?></td>
                <td>
                    <?php if($temDivergencia): ?>
                        <span class="badge bg-danger">Divergência</span>
                    <?php endif; ?>

                    <?php if($temAvaria): ?>
                        <span class="badge bg-warning text-dark">Avaria</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="progress">
                        <div class="progress-bar bg-<?php echo e($percentual == 100 ? 'success' : ($percentual > 0 ? 'info' : 'secondary')); ?>" style="width: <?php echo e($percentual); ?>%;">
                            <?php echo e($percentual); ?>%
                        </div>
                    </div>
                </td>
                <td>
                    <?php if($itensConferidos === 0 && in_array($userTipo, ['admin', 'conferente'])): ?>
                        <a href="<?php echo e(route('setores.conferencia.telaFotoInicio', $recebimento->id)); ?>" class="btn btn-primary btn-sm">
                            Iniciar Conferência
                        </a>
                    <?php endif; ?>

                    <?php if($recebimento->status === 'conferido' && in_array($nivel, ['admin', 'documental', 'recebimento'])): ?>
                        <a href="<?php echo e(route('setores.conferencia.formRessalva', $recebimento->id)); ?>" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-chat-left-dots"></i> Adicionar Ressalva
                        </a>
                    <?php endif; ?>

                    <?php if($recebimento->status === 'conferido' && in_array($nivel, ['admin', 'documental', 'recebimento'])): ?>
                        <a href="<?php echo e(route('setores.conferencia.relatorio', $recebimento->id)); ?>" target="_blank" class="btn btn-sm btn-outline-dark">
                            <i class="bi bi-file-earmark-pdf"></i> PDF
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/recebimento/painel.blade.php ENDPATH**/ ?>