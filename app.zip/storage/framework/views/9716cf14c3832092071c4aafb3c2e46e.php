

<?php $__env->startSection('title', 'Nova Contagem de Paletes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-4">➕ Nova Contagem de Paletes</h4>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>⚠️ <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('contagem.paletes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="tipo_palete" class="form-label">Tipo de Palete</label>
            <input type="text" class="form-control" id="tipo_palete" name="tipo_palete" value="<?php echo e(old('tipo_palete')); ?>" required>
        </div>

        <div class="mb-3">
            <label for="quantidade" class="form-label">Quantidade</label>
            <input type="number" class="form-control" id="quantidade" name="quantidade" min="1" value="<?php echo e(old('quantidade')); ?>" required>
        </div>

        <div class="d-flex justify-content-between">
            <a href="<?php echo e(route('contagem.paletes.index')); ?>" class="btn btn-secondary">
                <i class="uil uil-arrow-left"></i> Voltar
            </a>
            <button type="submit" class="btn btn-success">
                <i class="uil uil-save"></i> Salvar Contagem
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/contagem/paletes/create.blade.php ENDPATH**/ ?>