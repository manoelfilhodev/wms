

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="text-white text-center mb-5">Painel do Operador</h2>

    <div class="row justify-content-center">
        

        <div class="col-12 col-md-6 mb-3">
            <a href="<?php echo e(route('armazenagem.index')); ?>" class="btn btn-dark btn-lg w-100 d-flex align-items-center justify-content-center">
                <i class="mdi mdi-warehouse me-2 fs-4"></i> Armazenagem
            </a>
        </div>

        <div class="col-12 col-md-6 mb-3">
            <a href="<?php echo e(route('separacao.index')); ?>" class="btn btn-dark btn-lg w-100 d-flex align-items-center justify-content-center">
                <i class="mdi mdi-clipboard-text-outline me-2 fs-4"></i> Separação
            </a>
        </div>
        
        <div class="col-12 col-md-6 mb-3">
            <a href="<?php echo e(route('contagem.paletes.index')); ?>" class="btn btn-dark btn-lg w-100 d-flex align-items-center justify-content-center">
                 <i class="mdi mdi-package-variant me-2 fs-4"></i> Contagem Paletes
            </a>
        </div>

        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/painel_operador.blade.php ENDPATH**/ ?>