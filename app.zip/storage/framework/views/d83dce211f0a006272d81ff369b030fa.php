
<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-4">Separar Produto do Pedido #PED - <?php echo e($item->fo); ?></h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <p><strong>SKU:</strong> <?php echo e($item->sku); ?></p>
            <p><strong>Quantidade a Separar:</strong> <?php echo e($item->quantidade); ?></p>
            <p><strong>Posição:</strong> <?php echo e(isset($posicao) ? mb_strtoupper($posicao->codigo_posicao) : 'Não encontrado'); ?></p>

            <p><strong>FO:</strong> <?php echo e($item->fo); ?></p>
        </div>
    </div>

    <form method="POST" action="<?php echo e(route('separacoes.executar', $item->id)); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="quantidade_separada">Quantidade Separada</label>
            <input type="number" name="quantidade_separada" id="quantidade_separada" class="form-control" placeholder="Informe quanto foi separado" max="<?php echo e($item->quantidade); ?>" required>
        </div>

        <button type="submit" class="btn btn-success w-100">Confirmar Separação</button>
    </form>
    <a href="#" 
   class="btn btn-secondary w-100 mt-2"
   onclick="confirmarPular('<?php echo e(route('separacoes.pular', $item->id)); ?>')">
   Pular Posição
</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
function confirmarPular(url) {
    if (confirm('Tem certeza que deseja pular esta posição?')) {
        window.location.href = url;
    }
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/pedidos/separar_item.blade.php ENDPATH**/ ?>