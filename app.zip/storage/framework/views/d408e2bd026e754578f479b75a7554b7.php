

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="page-heading mb-4">
        <h3 class="text-dark fw-bold">Painel de Controle</h3>
    </div>

    <?php if(!empty($notificacoes)): ?>
    <div class="row mb-3">
        <div class="col-12">
            <?php $__currentLoopData = $notificacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-warning d-flex align-items-center justify-content-between" role="alert">
                <div>
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <strong><?php echo e($notificacao->tipo ?? 'Aviso'); ?>:</strong> <?php echo e($notificacao->mensagem); ?>

                </div>
                <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($notificacao->created_at)->diffForHumans()); ?></small>
            </div>
            <form action="<?php echo e(route('notificacoes.ler', $notificacao->id)); ?>" method="POST" class="ms-3">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <button class="btn btn-sm btn-outline-secondary" title="Marcar como lida">
                    <i class="bi bi-x-lg">Marcar como Lida</i>
                </button>
            </form>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>


    <div class="row g-4">
        <!-- Ocupação do CD -->
        <div class="col-xl-3 col-sm-6">
            <div class="card card-hover border-start border-secondary border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Ocupação do CD</h6>
                        <h4 class="fw-bold mb-0"><?php echo e(number_format($ocupacao_cd, 1)); ?>%</h4>
                    </div>
                    <div class="avatar bg-secondary text-white">
                        <i class="bi bi-bar-chart-line fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Armazenagens Hoje -->
        <div class="col-xl-3 col-sm-6">
            <div class="card card-hover border-start border-warning border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Armazenagens Hoje</h6>
                        <h4 class="fw-bold mb-0"><?php echo e($contagens['armazenagem'] ?? 0); ?></h4>
                    </div>
                    <div class="avatar bg-warning text-white">
                        <i class="bi bi-box-arrow-in-down fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Separações Hoje -->
        <div class="col-xl-3 col-sm-6">
            <div class="card card-hover border-start border-danger border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Separações Hoje</h6>
                        <h4 class="fw-bold mb-0"><?php echo e($contagens['separacao'] ?? 0); ?></h4>
                    </div>
                    <div class="avatar bg-danger text-white">
                        <i class="bi bi-box-arrow-up fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Paletes Contados Hoje -->
        <div class="col-xl-3 col-sm-6">
            <div class="card card-hover border-start border-info border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Paletes Contados Hoje</h6>
                        <h4 class="fw-bold mb-0"><?php echo e($contagens['paletes'] ?? 0); ?></h4>
                    </div>
                    <div class="avatar bg-info text-white">
                        <i class="bi bi-stack fs-4"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- Posições -->
        <div class="col-xl-4 col-sm-6">
            <div class="card card-hover border-start border-primary border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Posições Criadas</h6>
                        <h4 class="fw-bold mb-0"><?php echo e($totais['posicoes'] ?? 0); ?></h4>
                    </div>
                    <div class="avatar bg-primary text-white">
                        <i class="bi bi-box fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Produtos -->
        <div class="col-xl-4 col-sm-6">
            <div class="card card-hover border-start border-success border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Produtos Cadastrados</h6>
                        <h4 class="fw-bold mb-0"><?php echo e($totais['produtos'] ?? 0); ?></h4>
                    </div>
                    <div class="avatar bg-success text-white">
                        <i class="bi bi-tags fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Usuários -->
        <div class="col-xl-4 col-sm-6">
            <div class="card card-hover border-start border-dark border-5 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted mb-2">Usuários Ativos</h6>
                        <h4 class="fw-bold mb-0"><?php echo e($totais['usuarios'] ?? 0); ?></h4>
                    </div>
                    <div class="avatar bg-dark text-white">
                        <i class="bi bi-people fs-4"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <!-- Ranking Armazenagem -->
        <div class="col-xl-6 col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold border-bottom">Top 5 - Armazenagem (Últimos 7 dias)</div>
                <div class="card-body">
                    <div id="grafico-ranking-armazenagem"></div>
                </div>
            </div>
        </div>

        <!-- Ranking Separação -->
        <div class="col-xl-6 col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold border-bottom">Top 5 - Separação (Últimos 7 dias)</div>
                <div class="card-body">
                    <div id="grafico-ranking-separacao"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-4">
        <!-- Gráfico Armazenagem -->
        <div class="col-xl-4 col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold border-bottom">Armazenagens no Mês</div>
                <div class="card-body">
                    <div id="grafico-armazenagem"></div>
                </div>
            </div>
        </div>

        <!-- Gráfico Separação -->
        <div class="col-xl-4 col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold border-bottom">Separações no Mês</div>
                <div class="card-body">
                    <div id="grafico-separacao"></div>
                </div>
            </div>
        </div>

        <!-- Gráfico Paletes -->
        <div class="col-xl-4 col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold border-bottom">Paletes Contados no Mês</div>
                <div class="card-body">
                    <div id="grafico-paletes"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
    <div class="col-xl-12 col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom">
                <h6 class="mb-0 fw-semibold">Resumo do Dia</h6>
                <a href="<?php echo e(route('dashboard.resumo.pdf')); ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-file-earmark-pdf"></i> Exportar PDF
                </a>
            </div>
            <div class="card-body">
                <table class="table table-sm table-bordered mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Setor</th>
                            <th class="text-end">Quantidade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $resumoDia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor => $qtd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-uppercase"><?php echo e(str_replace('_', ' ', $setor)); ?></td>
                            <td class="text-end fw-semibold"><?php echo e($qtd); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
    function renderBarChart(id, label, nomes, quantidades, color) {
        const options = {
            chart: {
                type: 'bar',
                height: 250
            },
            series: [{
                name: label,
                data: quantidades
            }],
            xaxis: {
                categories: nomes
            },
            colors: [color],
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '50%',
                    borderRadius: 4
                }
            }
        };
        const chart = new ApexCharts(document.querySelector(id), options);
        chart.render();
    }

    document.addEventListener("DOMContentLoaded", function() {
        renderBarChart(
            '#grafico-ranking-armazenagem',
            'Armazenagem',
            <?php echo json_encode(collect($rankingOperadores['armazenagem']) -> pluck('nome'), 15, 512) ?>,
            <?php echo json_encode(collect($rankingOperadores['armazenagem']) -> pluck('total'), 15, 512) ?>,
            '#3b82f6'
        );

        renderBarChart(
            '#grafico-ranking-separacao',
            'Separação',
            <?php echo json_encode(collect($rankingOperadores['separacao']) -> pluck('nome'), 15, 512) ?>,
            <?php echo json_encode(collect($rankingOperadores['separacao']) -> pluck('total'), 15, 512) ?>,
            '#10b981'
        );
    });
</script>

<script>
    function renderGrafico(id, label, data, dias, color) {
        const options = {
            chart: {
                type: 'line',
                height: 250
            },
            series: [{
                name: label,
                data: data
            }],
            xaxis: {
                categories: dias,
                title: {
                    text: 'Dia do Mês'
                }
            },
            yaxis: {
                title: {
                    text: 'Qtd.'
                }
            },
            stroke: {
                curve: 'smooth'
            },
            colors: [color],
            markers: {
                size: 4
            }
        };

        const chart = new ApexCharts(document.querySelector(id), options);
        chart.render();
    }

    document.addEventListener("DOMContentLoaded", function() {
        renderGrafico('#grafico-armazenagem', 'Armazenagem', <?php echo json_encode($dadosMensais['armazenagem'], 15, 512) ?>, <?php echo json_encode($dadosMensais['dias'], 15, 512) ?>, '#3b82f6');
        renderGrafico('#grafico-separacao', 'Separação', <?php echo json_encode($dadosMensais['separacao'], 15, 512) ?>, <?php echo json_encode($dadosMensais['dias'], 15, 512) ?>, '#10b981');
        renderGrafico('#grafico-paletes', 'Paletes', <?php echo json_encode($dadosMensais['paletes'], 15, 512) ?>, <?php echo json_encode($dadosMensais['dias'], 15, 512) ?>, '#f97316');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/dashboard.blade.php ENDPATH**/ ?>