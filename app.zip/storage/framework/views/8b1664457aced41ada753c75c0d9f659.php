

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Itens do Recebimento - NF <?php echo e($recebimento->nota_fiscal); ?></h4>

    <a href="<?php echo e(route('recebimento.itens.create', $recebimento->id)); ?>" class="btn btn-primary float-end mb-3">Novo Item</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>SKU</th>
                <th>Descrição</th>
                <th>Quantidade</th>
                <th>Status</th>
                <th>Usuário</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->sku); ?></td>
                <td><?php echo e($item->descricao); ?></td>
                <td><?php echo e($item->quantidade); ?></td>
                <td><span class="badge bg-info"><?php echo e(ucfirst($item->status)); ?></span></td>
                <td><?php echo e($item->usuario->nome ?? '---'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/recebimento/itens/index.blade.php ENDPATH**/ ?>