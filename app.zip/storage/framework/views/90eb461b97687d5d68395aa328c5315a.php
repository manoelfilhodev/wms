

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Ressalva Pós-Conferência - NF <?php echo e($recebimento->nota_fiscal); ?></h4>

    <form method="POST" action="<?php echo e(route('setores.conferencia.salvarRessalva', $recebimento->id)); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="ressalva_assistente" class="form-label">Ressalva do Assistente</label>
            <textarea name="ressalva_assistente" class="form-control" rows="4" required><?php echo e($recebimento->ressalva_assistente); ?></textarea>
        </div>
        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="<?php echo e(route('setores.recebimento.painel')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/conferencia/ressalva.blade.php ENDPATH**/ ?>