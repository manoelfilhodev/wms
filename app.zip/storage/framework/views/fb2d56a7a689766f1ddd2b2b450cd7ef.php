<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © <?php echo e(date('Y')); ?> SYSTEX - Todos os direitos reservados.
            </div>
        </div>
    </div>
</footer><?php /**PATH /home3/systex91/public_html/wms/resources/views/partials/footer.blade.php ENDPATH**/ ?>