<?php
    $segments = Request::segments();
    $title = ucfirst(end($segments));
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title', $title); ?> | WMS 4.0</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Sistema WMS" name="description" />
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/app-creative.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />
    <link href="<?php echo e(asset('assets/css/app-creative-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style" />

    <style>
        .content::before {
            content: none !important;
        }

        .content > svg {
            display: none !important;
        }

        .sidebar-toggle, .vertical-menu-toggle, .menu-toggle {
            display: none !important;
        }

        .top-bar-operador {
            background-color: #111827;
            padding: 0.75rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar-operador span {
            color: #fff;
            font-weight: bold;
        }

        .top-bar-operador .btn {
            font-size: 0.9rem;
        }
    </style>

    <?php echo $__env->yieldContent('head'); ?>
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false,"leftSidebarCondensed":false,"darkMode":false}'>

    <div class="wrapper">

        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->tipo !== 'operador'): ?>
                <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>

        <div class="content-page">
            <div class="content">

                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->tipo !== 'operador'): ?>
                        <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php else: ?>
                        
                        <div class="top-bar-operador">
                            <span>Systex WMS</span>
                            <a href="<?php echo e(route('painel.operador')); ?>" class="btn btn-outline-light btn-sm">
                                <i class="bi bi-arrow-left"></i> Voltar ao Início
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="container-fluid mt-3">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

            <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH /home3/systex91/public_html/wms/resources/views/layouts/app.blade.php ENDPATH**/ ?>