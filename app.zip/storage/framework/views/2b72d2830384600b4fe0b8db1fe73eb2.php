

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Criar Novo Pedido com Lista de Itens</h4>

    <form method="POST" action="<?php echo e(route('pedidos.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Cole aqui os dados do pedido (CENTRO FO SKU QTDE):</label>
            <textarea name="itens_texto" rows="12" class="form-control" placeholder="D088 6100536850 KP.470.17 7&#10;D088 6100536850 KP.470.17 3" required></textarea>
        </div>
        <button type="submit" class="btn btn-success mt-3">Salvar Pedido</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/pedidos/create.blade.php ENDPATH**/ ?>