

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Recebimentos Pendentes de Conferência</h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>NF</th>
                <th>Fornecedor</th>
                <th>Transportadora</th>
                <th>Data</th>
                <th>Status</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recebimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($rec->nota_fiscal); ?></td>
                    <td><?php echo e($rec->fornecedor); ?></td>
                    <td><?php echo e($rec->transportadora); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($rec->data_recebimento)->format('d/m/Y')); ?></td>
                    <td>
                        <span class="badge bg-warning text-dark text-uppercase"><?php echo e($rec->status); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('setores.conferencia.itens', $rec->id)); ?>" class="btn btn-sm btn-outline-primary">
                            Iniciar Conferência
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">Nenhum recebimento pendente.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/conferencia/index.blade.php ENDPATH**/ ?>