

<?php $__env->startSection('content'); ?>
<style>
@media print {
    .etiqueta {
        width: 150mm;
        height: 80mm;
        page-break-after: always;
        padding: 6mm;
        box-sizing: border-box;
    }

    body * {
        visibility: hidden;
    }

    .print-wrapper, .print-wrapper * {
        visibility: visible;
    }

    .no-print {
        display: none !important;
    }
}

.etiqueta {
    width: 170mm;
    height: 100mm;
    padding: 3mm;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
    font-size: 26px;
    font-weight: bold;
    text-transform: uppercase;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.etiqueta .topo {
    display: flex;
    justify-content: space-between;
    font-size: 32px;
}
.etiqueta .conteudo {
    margin-top: 20px;
    line-height: 1.4;
}
</style>

<div class="container-fluid print-wrapper">
    <form method="GET" action="<?php echo e(route('etiquetas.html')); ?>" class="no-print">
        <div class="mb-3">
            <label for="dados" class="form-label">📋 Cole os dados do Excel (tabulados)</label>
            <textarea name="dados" id="dados" rows="7" class="form-control" placeholder="FO[TAB]REMESSA[TAB]COD_CLIENTE[TAB]CLIENTE[TAB]PRODUTO[TAB]QTD[TAB]CIDADE[TAB]UF" required></textarea>
        </div>
        <div class="form-group no-print">
            <label for="modo_impressao">Modo de Impressão:</label>
            <select name="modo_impressao" class="form-control w-auto d-inline-block" required>
                <option value="" selected disabled>Selecionar Tipo de Impressão</option>
                <option value="normal">Normal (1 etiqueta por unidade)</option>
                <option value="multiplo">Por múltiplo de embalagem</option>
            </select>
        </div>
        
        <div class="d-flex justify-content-end gap-2 mt-3">
    <button type="submit" class="btn btn-success">Gerar Etiquetas</button>
    <?php if(count($etiquetas)): ?>
        <div class="text-center no-print">
            <button class="btn btn-secondary" onclick="window.print()">🖨️ Imprimir Etiquetas</button>
        </div>
    <?php endif; ?>
    <a href="<?php echo e(route('etiquetas.hydra.historico')); ?>" class="btn btn-outline-secondary">
        Ver Histórico
    </a>
</div>

    </form>

    <hr class="my-4 no-print" />

    <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="etiqueta">
    <div class="topo">
        <div></div>
        <div class="text-end">
            FO <?php echo e($etiqueta->FO); ?>

        </div>
    </div>
    <div class="conteudo">
    <div style="font-size: 32px">REMESSA: <?php echo e($etiqueta->REMESSA); ?></div>
    <div>RECEBEDOR: <?php echo e($etiqueta->RECEBEDOR); ?></div>
    <div>CLIENTE: <?php echo e($etiqueta->CLIENTE); ?></div>
    <div>CIDADE: <?php echo e($etiqueta->CIDADE); ?></div>
    <div>UF: <?php echo e($etiqueta->UF); ?></div>
    <div>PRODUTO: <?php echo e($etiqueta->PRODUTO); ?></div>
    <div>QTDE PÇS: <?php echo e($etiqueta->QTD); ?></div>
    <div>DATA - HORA: <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i:s')); ?></div>
</div>
</div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/etiquetas/index.blade.php ENDPATH**/ ?>