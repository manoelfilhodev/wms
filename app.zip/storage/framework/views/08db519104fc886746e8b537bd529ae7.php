
<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Separação do Pedido #<?php echo e($pedido->numero_pedido); ?></h4>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>SKU</th>
                <th>Qtd</th>
                <th>Centro</th>
                <th>FO</th>
                <th>Conferido</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pedido->itensSeparacao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->sku); ?></td>
                    <td><?php echo e($item->quantidade); ?></td>
                    <td><?php echo e($item->centro); ?></td>
                    <td><?php echo e($item->fo); ?></td>
                    <td><?php echo $item->conferido ? '<span class=\"badge bg-success\">Sim</span>' : '<span class=\"badge bg-secondary\">Não</span>'; ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/pedidos/separacao_itens.blade.php ENDPATH**/ ?>