

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Teste POST: Conferência Item Manual</h4>

    <form action="<?php echo e(route('setores.conferencia.enviarItemManual', ['id' => 1])); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Quantidade Conferida</label>
            <input type="number" name="qtd_conferida" class="form-control" value="5">
        </div>

        <div class="mb-3">
            <label>Observação</label>
            <textarea name="observacao" class="form-control">Item bom</textarea>
        </div>

        <div class="mb-3">
            <input type="checkbox" name="avariado" value="1"> Avariado
        </div>

        <button type="submit" class="btn btn-primary">Testar Envio</button>
    </form> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/teste_post_conferencia.blade.php ENDPATH**/ ?>