

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-4">Histórico de Etiquetas - Hydra Metais</h4>

    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-3">
            <input type="text" name="fo" value="<?php echo e(request('fo')); ?>" class="form-control" placeholder="FO">
        </div>
        <div class="col-md-3">
            <input type="text" name="produto" value="<?php echo e(request('produto')); ?>" class="form-control" placeholder="Produto">
        </div>
        <div class="col-md-3">
            <input type="text" name="cliente" value="<?php echo e(request('cliente')); ?>" class="form-control" placeholder="Cliente">
        </div>
        <div class="col-md-3">
            <input type="date" name="data" value="<?php echo e(request('data')); ?>" class="form-control">
        </div>
        <div class="col-md-12 text-end">
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </div>
    </form>

    <form action="<?php echo e(route('etiquetas.hydra.imprimir')); ?>" method="POST" target="_blank">
    <?php echo csrf_field(); ?>

    <div class="text-start mb-2">
        <button type="submit" class="btn btn-primary">
            <i class="mdi mdi-printer me-1"></i> Imprimir Selecionadas
        </button>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th><input type="checkbox" id="checkAll"></th>
                <th>Data</th>
                <th>FO</th>
                <th>Produto</th>
                <th>Cliente</th>
                <th>Cidade</th>
                <th>UF</th>
                <th>Qtd</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?php echo e($etiqueta->id); ?>"></td>
                    <td><?php echo e(\Carbon\Carbon::parse($etiqueta->data_gerada)->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e($etiqueta->fo); ?></td>
                    <td><?php echo e($etiqueta->produto); ?></td>
                    <td><?php echo e($etiqueta->cliente); ?></td>
                    <td><?php echo e($etiqueta->cidade); ?></td>
                    <td><?php echo e($etiqueta->uf); ?></td>
                    <td><?php echo e($etiqueta->qtd); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</form>


     <div class="mt-3">
        <?php echo e($etiquetas->withQueryString()->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<script>
    document.getElementById('checkAll').addEventListener('change', function () {
        const checkboxes = document.querySelectorAll('input[name="ids[]"]');
        checkboxes.forEach(cb => cb.checked = this.checked);
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/etiquetas/hydra/historico.blade.php ENDPATH**/ ?>