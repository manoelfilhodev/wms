<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatório de Conferência</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        h1, h2, h3, h4 { margin-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; text-align: left; }
        .section { margin-top: 20px; }
        .status-ok { color: green; font-weight: bold; }
        .status-divergente { color: red; font-weight: bold; }
        .status-avariado { color: orange; font-weight: bold; }
        img { margin-top: 10px; max-width: 100%; height: auto; }
        .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
        .footer { position: fixed; bottom: 10px; left: 0; right: 0; text-align: center; font-size: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('logo.png')); ?>" height="50" alt="Logo">
        <h2>Relatório de Conferência Cega - Dexco Cajamar</h2>
        <small>Gerado em: <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i')); ?></small>
    </div>

    <div class="section">
        <h4>Dados do Recebimento</h4>
        <p><strong>Nota Fiscal:</strong> <?php echo e($recebimento->nota_fiscal); ?></p>
        <p><strong>Fornecedor:</strong> <?php echo e($recebimento->fornecedor); ?></p>
        <p><strong>Data Recebimento:</strong> <?php echo e(\Carbon\Carbon::parse($recebimento->data_recebimento)->format('d/m/Y')); ?></p>
        <p><strong>Transportadora:</strong> <?php echo e($recebimento->transportadora); ?></p>
        <p><strong>Motorista:</strong> <?php echo e($recebimento->motorista); ?></p>
        <p><strong>Placa:</strong> <?php echo e($recebimento->placa); ?></p>
        <p><strong>Doca:</strong> <?php echo e($recebimento->doca); ?></p>
        <p><strong>Tipo de Carga:</strong> <?php echo e($recebimento->tipo); ?></p>
    </div>

    <div class="section">
        <h4>Itens Conferidos</h4>
        <table>
            <thead>
                <tr>
                    <th>Data Conf</th>
                    <th>SKU</th>
                    <th>Qtd Esperada</th>
                    <th>Qtd Conf</th>
                    <th>Status</th>
                    <th>Observação</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d/m/Y')); ?></td>
                        <td><?php echo e($item->sku); ?></td>
                        <td><?php echo e($item->quantidade); ?></td>
                        <td><?php echo e($item->qtd_conferida); ?></td>
                        <td>
                            <?php if($item->divergente): ?>
                                <span class="status-divergente">Divergente</span>
                            <?php elseif($item->avariado): ?>
                                <span class="status-avariado">Avariado</span>
                            <?php else: ?>
                                <span class="status-ok">OK</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->observacao); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php if($recebimento->foto_inicio_veiculo): ?>
        <div class="section">
            <h4>Foto Inicial do Veículo</h4>
            <img src="<?php echo e(storage_path('app/public/' . $recebimento->foto_inicio_veiculo)); ?>">
        </div>
    <?php endif; ?>

    <?php if($recebimento->foto_fim_veiculo): ?>
        <div class="section">
            <h4>Foto Final do Veículo</h4>
            <img src="<?php echo e(storage_path('app/public/' . $recebimento->foto_fim_veiculo)); ?>">
        </div>
    <?php endif; ?>

    <?php if($recebimento->ressalva_assistente): ?>
        <div class="section">
            <h4>Ressalva do Assistente</h4>
            <p><?php echo e($recebimento->ressalva_assistente); ?></p>
        </div>
    <?php endif; ?>

    <?php if($recebimento->assinatura_conferente): ?>
        <div class="section">
            <h4>Assinatura do Conferente</h4>
            <p><?php echo e($recebimento->assinatura_conferente); ?></p>
        </div>
    <?php endif; ?>

    <div class="footer">
        SYSTEX Sistemas Inteligentes &copy; <?php echo e(date('Y')); ?> - www.systex.com.br
    </div>
</body>
</html>
<?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/conferencia/relatorio_pdf.blade.php ENDPATH**/ ?>