<?php
    $segments = Request::segments();
    $title = ucfirst(end($segments));
?>
<div class="row">
<div class="col-12">
<div class="page-title-box">
    <div class="page-title-left">
        <ol class="breadcrumb m-0">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Início</a></li>

            <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $path = implode('/', array_slice($segments, 0, $index + 1));
                    $label = ucwords(str_replace('-', ' ', $segment));
                ?>

                <?php if($loop->last): ?>
                    <li class="breadcrumb-item active"><?php echo e($label); ?></li>
                <?php else: ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(url($path)); ?>"><?php echo e($label); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>
</div>
</div>
</div>
<?php /**PATH /home3/systex91/public_html/wms/resources/views/partials/breadcrumb-auto.blade.php ENDPATH**/ ?>