<div class="navbar-custom">
    <ul class="list-unstyled topbar-menu float-end mb-0">
        <li class="dropdown">
            <a class="nav-link dropdown-toggle nav-user me-0" data-bs-toggle="dropdown" href="#" role="button">
                <span class="d-none d-md-inline-block ms-1 fw-semibold"><?php echo e(session('nome')); ?></span><br>
                <small class="d-none d-md-inline-block ms-1"> <?php echo e(session('tipo')); ?> </small>
            </a>
            <div class="dropdown-menu dropdown-menu-end">
                <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"><i class="mdi mdi-logout"></i> Sair</a>
            </div>
        </li>
    </ul>
    <button class="button-menu-mobile open-left">
        <i class="mdi mdi-menu"></i>
    </button>
</div>
<?php /**PATH /home3/systex91/public_html/wms/resources/views/partials/header.blade.php ENDPATH**/ ?>