<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Reimpressão de Etiquetas</title>
    <style>
        @media print {
            .etiqueta {
                width: 80mm;
                height: 100mm;
                page-break-after: always;
                padding: 6mm;
                box-sizing: border-box;
            }
            body * {
                visibility: hidden;
            }
            .print-wrapper, .print-wrapper * {
                visibility: visible;
            }
        }

        body {
            font-family: Arial, sans-serif;
        }

        .etiqueta {
    width: 170mm;
    height: 100mm;
    padding: 3mm;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
    font-size: 22px;
    font-weight: bold;
    text-transform: uppercase;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

        .etiqueta .topo {
            display: flex;
            justify-content: space-between;
            font-size: 26px;
        }

        .etiqueta .conteudo {
            line-height: 1.4;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="print-wrapper">
    <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="etiqueta">
            <div class="topo">
                <div></div>
                <div class="text-end">
                    DOCA <?php echo e($etiqueta->doca); ?><br>
                    <?php echo e($etiqueta->fo); ?>

                </div>
            </div>
            <div class="conteudo">
                <div>REMESSA: <?php echo e($etiqueta->remessa); ?></div>
                <div>CLIENTE: <?php echo e($etiqueta->cliente); ?></div>
                <div>CIDADE: <?php echo e($etiqueta->cidade); ?></div>
                <div>UF: <?php echo e($etiqueta->uf); ?></div>
                <div>PRODUTO: <?php echo e($etiqueta->produto); ?></div>
                <div>QTDE PÇS: 1</div>
                <div>DATA - HORA: <?php echo e(\Carbon\Carbon::parse($etiqueta->data_gerada)->format('d/m/Y H:i:s')); ?></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    window.onload = () => {
        setTimeout(() => {
            window.print();
        }, 800);
    };
</script>
</body>
</html><?php /**PATH /home3/systex91/public_html/wms/resources/views/etiquetas/hydra/reimprimir.blade.php ENDPATH**/ ?>