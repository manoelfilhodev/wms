

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-4">Separações em Andamento</h4>

    <?php if($separacoes->isEmpty()): ?>
        <div class="alert alert-info">Nenhum pedido em separação no momento.</div>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Ação</th>
                    <th>FO</th>
                    <th>Pedido</th>
                    
                    <th>Data</th>
                    <th>Status</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $separacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $primeiroNaoConferido = $pedido->itensSeparacao->where('conferido', false)->first();
                    ?>
                     
                    <tr>
                        <td>
                            <?php if($primeiroNaoConferido): ?>
                                <a href="<?php echo e(route('separacoes.form', $primeiroNaoConferido->id)); ?>" class="btn btn-sm btn-primary">
                                    Separar Agora
                                </a>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($pedido->itensSeparacao->first()->fo ?? '-'); ?></td>
                        <td>#PED<?php echo e($pedido->numero_pedido); ?></td>
                        
                        <td><?php echo e($pedido->created_at ? $pedido->created_at->format('d/m/Y H:i') : '-'); ?></td>
                        <td>
                            <?php if($primeiroNaoConferido): ?>
                                <span class="badge bg-warning text-dark">Em Andamento</span>
                            <?php else: ?>
                                <span class="badge bg-success">Finalizado</span>
                            <?php endif; ?>
                        </td>
                       
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/separacao/separacoes/index.blade.php ENDPATH**/ ?>