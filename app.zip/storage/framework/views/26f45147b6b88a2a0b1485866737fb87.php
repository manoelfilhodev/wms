

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Adicionar Item à NF <?php echo e($recebimento->nota_fiscal); ?></h4>

    <form action="<?php echo e(route('recebimento.itens.store', $recebimento->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>SKU</label>
            <input type="text" name="sku" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Descrição</label>
            <input type="text" name="descricao" class="form-control">
        </div>

        <div class="mb-3">
            <label>Quantidade</label>
            <input type="number" name="quantidade" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-select" required>
                <option value="pendente">Pendente</option>
                <option value="conferido">Conferido</option>
                <option value="armazenado">Armazenado</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Salvar Item</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/systex91/public_html/wms/resources/views/setores/recebimento/itens/create.blade.php ENDPATH**/ ?>