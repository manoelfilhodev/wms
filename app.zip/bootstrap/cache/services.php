<?php return array (
  'providers' => 
  array (
    0 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
    1 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
    2 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
    3 => 'Illuminate\\Cookie\\CookieServiceProvider',
    4 => 'Illuminate\\Session\\SessionServiceProvider',
    5 => 'Illuminate\\View\\ViewServiceProvider',
    6 => 'Illuminate\\Database\\DatabaseServiceProvider',
    7 => 'Illuminate\\Auth\\AuthServiceProvider',
    8 => 'Illuminate\\Hashing\\HashServiceProvider',
    9 => 'Barryvdh\\DomPDF\\ServiceProvider',
    10 => 'Laravel\\Pail\\PailServiceProvider',
    11 => 'Laravel\\Sail\\SailServiceProvider',
    12 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    13 => 'Laravel\\Tinker\\TinkerServiceProvider',
    14 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    15 => 'Carbon\\Laravel\\ServiceProvider',
    16 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    17 => 'Termwind\\Laravel\\TermwindServiceProvider',
    18 => 'SocialiteProviders\\Manager\\ServiceProvider',
    19 => 'App\\Providers\\AppServiceProvider',
    20 => 'App\\Providers\\EventServiceProvider',
    21 => 'App\\Providers\\AppServiceProvider',
    22 => 'App\\Providers\\EventServiceProvider',
    23 => 'App\\Providers\\AppServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
    1 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
    2 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
    3 => 'Illuminate\\Cookie\\CookieServiceProvider',
    4 => 'Illuminate\\Session\\SessionServiceProvider',
    5 => 'Illuminate\\View\\ViewServiceProvider',
    6 => 'Illuminate\\Database\\DatabaseServiceProvider',
    7 => 'Illuminate\\Auth\\AuthServiceProvider',
    8 => 'Barryvdh\\DomPDF\\ServiceProvider',
    9 => 'Laravel\\Pail\\PailServiceProvider',
    10 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    11 => 'Carbon\\Laravel\\ServiceProvider',
    12 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    13 => 'Termwind\\Laravel\\TermwindServiceProvider',
    14 => 'App\\Providers\\AppServiceProvider',
    15 => 'App\\Providers\\EventServiceProvider',
    16 => 'App\\Providers\\AppServiceProvider',
    17 => 'App\\Providers\\EventServiceProvider',
    18 => 'App\\Providers\\AppServiceProvider',
  ),
  'deferred' => 
  array (
    'validator' => 'Illuminate\\Validation\\ValidationServiceProvider',
    'validation.presence' => 'Illuminate\\Validation\\ValidationServiceProvider',
    'translator' => 'Illuminate\\Translation\\TranslationServiceProvider',
    'translation.loader' => 'Illuminate\\Translation\\TranslationServiceProvider',
    'hash' => 'Illuminate\\Hashing\\HashServiceProvider',
    'hash.driver' => 'Illuminate\\Hashing\\HashServiceProvider',
    'Laravel\\Sail\\Console\\InstallCommand' => 'Laravel\\Sail\\SailServiceProvider',
    'Laravel\\Sail\\Console\\PublishCommand' => 'Laravel\\Sail\\SailServiceProvider',
    'Laravel\\Socialite\\Contracts\\Factory' => 'SocialiteProviders\\Manager\\ServiceProvider',
    'command.tinker' => 'Laravel\\Tinker\\TinkerServiceProvider',
  ),
  'when' => 
  array (
    'Illuminate\\Validation\\ValidationServiceProvider' => 
    array (
    ),
    'Illuminate\\Translation\\TranslationServiceProvider' => 
    array (
    ),
    'Illuminate\\Hashing\\HashServiceProvider' => 
    array (
    ),
    'Laravel\\Sail\\SailServiceProvider' => 
    array (
    ),
    'Laravel\\Socialite\\SocialiteServiceProvider' => 
    array (
    ),
    'Laravel\\Tinker\\TinkerServiceProvider' => 
    array (
    ),
    'SocialiteProviders\\Manager\\ServiceProvider' => 
    array (
    ),
  ),
);
