<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use App\Exports\LogsExport;
use App\Http\Controllers\Auth\MicrosoftController;

use App\Http\Controllers\{
    AuthController,
    UserController,
    DashboardController,
    LogController,
    ContagemPaleteController,
    EtiquetaController,
    RelatorioController
};

use App\Http\Controllers\Setores\{
    RecebimentoController,
    ArmazenagemController,
    SeparacaoController,
    ConferenciaController,
    PedidoController,
    SeparacaoItemController,
    ExecutarSeparacaoController
};

Route::get('/teste', function () {
    return 'Laravel funcionando';
});

Route::get('/login/microsoft', [MicrosoftController::class, 'redirectToProvider'])->name('login.microsoft');
Route::get('/login/microsoft/callback', [MicrosoftController::class, 'handleProviderCallback']);

Route::get('/etiquetas/html', [EtiquetaController::class, 'viewHtml']);


Route::get('/separacoes/itens/{id}/pular', [SeparacaoController::class, 'pular'])->name('separacoes.pular');


Route::get('/separacoes/pendencias', [SeparacaoController::class, 'pendencias'])->name('separacoes.pendencias');


Route::get('/liberar-posicao/{id}', [SeparacaoController::class, 'liberarPosicao']);


Route::get('/dashboard/resumo/pdf', [DashboardController::class, 'exportarResumoDiaPDF'])->name('dashboard.resumo.pdf');

Route::put('/notificacoes/{id}/ler', [DashboardController::class, 'marcarNotificacaoLida'])->name('notificacoes.ler');

Route::get('/', function () {
    return redirect('/login');
});

Route::get('/etiquetas/hydra/reimprimir/{fo}', [EtiquetaController::class, 'reimprimirSelecionar'])->name('etiquetas.hydra.reimprimir');
Route::post('/etiquetas/hydra/imprimir', [EtiquetaController::class, 'imprimirSelecionadas'])->name('etiquetas.hydra.imprimir');


Route::get('/etiquetas/hydra/historico', [EtiquetaController::class, 'historico'])->name('etiquetas.hydra.historico');
Route::get('/etiquetas/hydra', [\App\Http\Controllers\EtiquetaController::class, 'viewHtml'])->name('etiquetas.hydra');
Route::get('/etiquetas/hydra/reimprimir/{fo}', [EtiquetaController::class, 'reimprimir'])->name('etiquetas.hydra.reimprimir');



Route::get('/etiquetas/html', [EtiquetaController::class, 'viewHtml'])->name('etiquetas.html');

Route::get('/etiquetas/gerar', [EtiquetaController::class, 'gerar'])->name('etiquetas.gerar');


Route::get('/painel-operador', function () {
    return view('painel_operador');
})->name('painel.operador')->middleware(['auth']);


Route::get('/separacoes/linha/manual', function () {
    return view('setores.separacao.linha.separar_manual');
})->name('separacoes.linha.manual');

Route::post('/separacoes/linha/manual/salvar', [\App\Http\Controllers\Setores\SeparacaoController::class, 'salvarLinhaManual'])->name('separacoes.salvarLinhaManual');


Route::get('/separacoes/linha/{id}', [SeparacaoController::class, 'linha'])->name('separacoes.linha');


Route::get('/separacoes/linha/{id}', [SeparacaoController::class, 'linha'])->name('separacoes.linha');
Route::post('/separacoes/store', [SeparacaoController::class, 'store'])->name('separacoes.store');

Route::get('/setores/separacao/separacoes', [SeparacaoController::class, 'listarEmAndamento'])->name('separacoes.andamento');


Route::get('/separacoes/separar/{id}', [ExecutarSeparacaoController::class, 'separarItem'])->name('separacoes.separar_item');
Route::post('/separacoes/separar/{id}', [ExecutarSeparacaoController::class, 'executar'])->name('separacoes.executar');
Route::get('/separacoes/andamento', [SeparacaoController::class, 'index'])->name('separacoes.andamento');


Route::get('/separacoes/separar/{item_id}', [ExecutarSeparacaoController::class, 'mostrarFormSeparar'])->name('separacoes.form');
Route::get('/separacoes/separar/{item_id}', [ExecutarSeparacaoController::class, 'mostrarFormSeparar'])->name('separacoes.form');
Route::post('/separacoes/separar/{item_id}', [ExecutarSeparacaoController::class, 'executar'])->name('separacoes.executar');


Route::get('/separacoes/itens/{pedido_id}', [SeparacaoController::class, 'verItensSeparacao'])->name('separacoes.itens');


Route::prefix('separacoes')->middleware('auth')->group(function () {
    Route::post('/iniciar/{pedido_id}', [SeparacaoController::class, 'iniciar'])->name('separacoes.iniciar');
    Route::get('/{id}', [SeparacaoController::class, 'show'])->name('separacoes.show'); // se ainda não tiver
});


Route::prefix('pedidos')->middleware('auth')->group(function () {
    Route::get('/', [PedidoController::class, 'index'])->name('pedidos.index');
});


Route::prefix('separacoes')->middleware('auth')->group(function () {
    Route::get('/', [SeparacaoController::class, 'listarEmAndamento'])->name('separacoes.index');
});



Route::prefix('pedidos')->middleware('auth')->group(function () {
    Route::get('/criar', [PedidoController::class, 'create'])->name('pedidos.create');
    Route::post('/store', [PedidoController::class, 'store'])->name('pedidos.store');
});


Route::prefix('pedidos')->middleware('auth')->group(function () {
    Route::get('/', [PedidoController::class, 'index'])->name('pedidos.index');
    Route::get('/criar', [PedidoController::class, 'create'])->name('pedidos.create');
    Route::post('/store', [PedidoController::class, 'store'])->name('pedidos.store');
    Route::get('/{id}', [PedidoController::class, 'show'])->name('pedidos.show');
});


Route::prefix('separacoes')->middleware('auth')->group(function () {
    Route::get('/novo-pedido', [SeparacaoController::class, 'criarPedido'])->name('separacoes.novoPedido');
    Route::post('/salvar-pedido', [SeparacaoController::class, 'salvarPedido'])->name('separacoes.salvarPedido');
    Route::get('/{pedido_id}/nova', [SeparacaoController::class, 'novaSeparacao'])->name('separacoes.nova');
    Route::post('/{pedido_id}/salvar', [SeparacaoController::class, 'salvarSeparacao'])->name('separacoes.salvarSeparacao');
    Route::get('/{id}/detalhes', [SeparacaoController::class, 'mostrarSeparacao'])->name('separacoes.show');
});


Route::get('/setores/conferencia/{id}/ressalva', [ConferenciaController::class, 'formRessalva'])->name('setores.conferencia.formRessalva');
Route::post('/setores/conferencia/{id}/ressalva', [ConferenciaController::class, 'salvarRessalva'])->name('setores.conferencia.salvarRessalva');


Route::post('/setores/conferencia/{id}/ressalva', [ConferenciaController::class, 'salvarRessalva'])->name('setores.conferencia.salvarRessalva');

Route::get('/setores/conferencia/{id}/foto-inicio', [ConferenciaController::class, 'telaFotoInicio'])->name('setores.conferencia.telaFotoInicio');


Route::post('/setores/conferencia/{id}/reabrir', [ConferenciaController::class, 'reabrir'])->name('setores.conferencia.reabrir');

Route::get('/setores/recebimento/painel', [RecebimentoController::class, 'painel'])->name('setores.recebimento.painel');
Route::get('/setores/recebimento/painel/{id}', [RecebimentoController::class, 'detalharPainel'])->name('setores.recebimento.painel.detalhado');



Route::get('setores/conferencia/item/{recebimento_id}/{item_id}/conferir', [ConferenciaController::class, 'formConferirItem'])->name('setores.conferencia.formConferirItem');

// Exibir o formulário de conferência do item (GET)
Route::get('setores/conferencia/{recebimento_id}/item/{item_id}/conferir', [ConferenciaController::class, 'formConferirItem'])
    ->name('setores.conferencia.formConferirItem');

// Salvar os dados da conferência do item (POST)
Route::post('setores/conferencia/{recebimento_id}/item/{item_id}/conferir', [ConferenciaController::class, 'salvarConferenciaItem'])
    ->name('setores.conferencia.salvarConferenciaItem');

// Exibe o formulário de conferência manual
Route::get('setores/conferencia/item/{id}/enviar-manual', [ConferenciaController::class, 'formItemManual'])->name('setores.conferencia.formItemManual');

// Salva os dados da conferência
Route::post('setores/conferencia/item/{id}/enviar-manual', [ConferenciaController::class, 'enviarItemManual'])->name('setores.conferencia.enviarItemManual');



Route::post('/setores/conferencia/item/{id}/enviar-manual', [ConferenciaController::class, 'enviarItemManual'])
    ->name('setores.conferencia.enviarItemManual');


Route::get('/teste-conferencia', function () {
    return view('teste_post_conferencia');
});

Route::post('/setores/conferencia/item/{id}/conferir', [ConferenciaController::class, 'salvarItem'])
    ->name('setores.conferencia.salvarItem');

// Grupo de rotas protegidas para conferência
Route::middleware(['auth'])->prefix('setores/conferencia')->group(function () {

    // Página inicial para enviar a foto do início do veículo
    Route::get('/{id}/foto', [ConferenciaController::class, 'telaFotoInicio'])->name('setores.conferencia.foto');
    Route::post('/{id}/salvar-foto', [ConferenciaController::class, 'salvarFotoInicio'])->name('setores.conferencia.salvarFotoInicio');

    // Página de itens para conferência
    Route::get('/{id}/itens', [ConferenciaController::class, 'itens'])->name('setores.conferencia.itens');

    // Página de conferência individual de item
    Route::get('item/{id}/conferir', [ConferenciaController::class, 'formConferirItem'])->name('setores.conferencia.formConferirItem');

    // Salvamento de conferência de item
    Route::post('item/{id}/conferir', [ConferenciaController::class, 'salvarItem'])->name('setores.conferencia.salvarItem');

    // Fechamento da conferência
    Route::post('/{id}/finalizar', [ConferenciaController::class, 'finalizar'])->name('setores.conferencia.finalizar');

    // Relatório em PDF
    Route::get('/{id}/relatorio', [ConferenciaController::class, 'gerarRelatorio'])->name('setores.conferencia.relatorio');
});


Route::middleware(['auth'])->prefix('setores/conferencia')->group(function () {
    Route::get('item/{id}/conferir', [ConferenciaController::class, 'formConferirItem'])->name('setores.conferencia.formConferirItem');
});


Route::middleware('auth')->group(function () {
    Route::post('/setores/conferencia/item/{id}/conferir', [ConferenciaController::class, 'contar'])->name('setores.conferencia.contar');
});



Route::post('/setores/conferencia/{id}/salvar-foto', [ConferenciaController::class, 'salvarFotoInicio'])->name('setores.conferencia.salvarFotoInicio');


Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware(['auth'])->group(function () {

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Apenas admins

    Route::get('/usuarios', [UserController::class, 'index'])->name('usuarios.index');
    Route::get('/usuarios/novo', [UserController::class, 'create'])->name('usuarios.create');
    Route::post('/usuarios', [UserController::class, 'store'])->name('usuarios.store');
    Route::get('/usuarios/{id}/editar', [UserController::class, 'edit'])->name('usuarios.edit');
    Route::put('/usuarios/{id}', [UserController::class, 'update'])->name('usuarios.update');
    Route::delete('/usuarios/{id}', [UserController::class, 'destroy'])->name('usuarios.destroy');
});

Route::prefix('setores')->middleware('auth')->group(function () {
    Route::prefix('recebimento')->group(function () {
        Route::get('/conferencia', [RecebimentoController::class, 'index'])->name('recebimento.index');
        Route::post('/conferir', [RecebimentoController::class, 'conferir'])->name('recebimento.conferir');
    });

    Route::prefix('armazenagem')->group(function () {
        Route::get('/', [ArmazenagemController::class, 'index'])->name('armazenagem.index');
        Route::post('/', [ArmazenagemController::class, 'store'])->name('armazenagem.store');
    });

    Route::prefix('separacao')->group(function () {
        Route::get('/', [SeparacaoController::class, 'index'])->name('separacao.index');
        Route::post('/', [SeparacaoController::class, 'store'])->name('separacao.store');
    });
});

Route::get('/armazenagem/buscar-skus', [ArmazenagemController::class, 'buscarSkus'])->name('armazenagem.buscarSkus');
Route::get('/armazenagem/buscar-descricao', [ArmazenagemController::class, 'buscarDescricao'])->name('armazenagem.buscarDescricao');
Route::get('/armazenagem/buscar-posicoes', [ArmazenagemController::class, 'buscarPosicoes'])->name('armazenagem.buscarPosicoes');

Route::prefix('logs')->middleware(['auth'])->group(function () {
    Route::get('/', [App\Http\Controllers\LogController::class, 'index'])->name('logs.index');
});

Route::prefix('relatorios')->middleware(['auth'])->group(function () {
    Route::get('/', [App\Http\Controllers\RelatorioController::class, 'index'])->name('relatorios.index');
});

Route::middleware(['auth'])->prefix('logs')->group(function () {
    Route::get('/', [LogController::class, 'index'])->name('logs.index');
    Route::get('/export/excel', [LogController::class, 'exportExcel'])->name('logs.export.excel');
    Route::get('/export/pdf', [LogController::class, 'exportPDF'])->name('logs.export.pdf');
});



Route::middleware(['auth'])->prefix('relatorios')->group(function () {
    Route::get('/separacoes', [RelatorioController::class, 'separacoes'])->name('relatorios.separacoes');
});




Route::middleware(['auth'])->prefix('relatorios')->group(function () {
    Route::get('/', [RelatorioController::class, 'index'])->name('relatorios.index');
    Route::get('/separacoes', [RelatorioController::class, 'separacoes'])->name('relatorios.separacoes');
    Route::get('/separacoes/export/excel', [RelatorioController::class, 'exportSeparacoesExcel'])->name('relatorios.separacoes.excel');
    Route::get('/separacoes/export/pdf', [RelatorioController::class, 'exportSeparacoesPDF'])->name('relatorios.separacoes.pdf');


    Route::get('/armazenagem', [RelatorioController::class, 'armazenagem'])->name('relatorios.armazenagem');
    Route::get('/armazenagem/export/excel', [RelatorioController::class, 'exportArmazenagemExcel'])->name('relatorios.armazenagem.excel');
    Route::get('/armazenagem/export/pdf', [RelatorioController::class, 'exportArmazenagemPDF'])->name('relatorios.armazenagem.pdf');
});


Route::prefix('contagem')->middleware('auth')->group(function () {
    Route::get('/paletes', [ContagemPaleteController::class, 'index'])->name('contagem.paletes.index');
    Route::get('/paletes/novo', [ContagemPaleteController::class, 'create'])->name('contagem.paletes.create');
    Route::post('/paletes', [ContagemPaleteController::class, 'store'])->name('contagem.paletes.store');
});

Route::get('/paletes/export/excel', [ContagemPaleteController::class, 'exportExcel'])->name('contagem.paletes.excel');

Route::get('/paletes/export/pdf', [ContagemPaleteController::class, 'exportPaletesPDF'])
    ->name('contagem.paletes.pdf');

use App\Http\Controllers\Setores\RecebimentoItemController;

Route::prefix('recebimento/itens')->middleware('auth')->group(function () {
    Route::get('/{recebimento_id}', [RecebimentoItemController::class, 'index'])->name('recebimento.itens.index');
    Route::get('/{recebimento_id}/novo', [RecebimentoItemController::class, 'create'])->name('recebimento.itens.create');
    Route::post('/{recebimento_id}/store', [RecebimentoItemController::class, 'store'])->name('recebimento.itens.store');
});

Route::prefix('setores')->middleware('auth')->group(function () {
    Route::prefix('recebimento')->group(function () {
        Route::get('/painel', [RecebimentoController::class, 'painel'])->name('setores.recebimento.painel');
    });
});


Route::prefix('setores')->middleware('auth')->group(function () {
    Route::prefix('recebimento')->group(function () {
        Route::get('/painel', [RecebimentoController::class, 'painel'])->name('setores.recebimento.painel');
        Route::get('/novo', [RecebimentoController::class, 'create'])->name('setores.recebimento.create');
        Route::post('/store', [RecebimentoController::class, 'store'])->name('setores.recebimento.store'); // 👈 ESSA LINHA
    });
});


Route::prefix('setores')->middleware(['auth'])->group(function () {
    Route::prefix('conferencia')->group(function () {
        Route::get('/', [ConferenciaController::class, 'index'])->name('setores.conferencia.index');
        Route::get('/{id}/itens', [ConferenciaController::class, 'itens'])->name('setores.conferencia.itens');
        Route::post('/{id}/contar', [ConferenciaController::class, 'contar'])->name('setores.conferencia.contar');
    });
});

Route::get('/setores/conferencia/{id}/relatorio', [ConferenciaController::class, 'gerarRelatorioPDF'])->name('setores.conferencia.relatorio');
Route::post('/setores/conferencia/{id}/finalizar', [ConferenciaController::class, 'finalizar'])->name('setores.conferencia.finalizar');
Route::post('/setores/conferencia/item/{id}/conferir', [ConferenciaController::class, 'conferirItem'])->name('setores.conferencia.item.conferir');
Route::post('/setores/conferencia/{id}/iniciar', [ConferenciaController::class, 'salvarFotoInicio'])->name('setores.conferencia.iniciar');
Route::get('/setores/conferencia/{id}/foto', [ConferenciaController::class, 'telaFotoInicio'])->name('setores.conferencia.foto');
Route::post('/setores/conferencia/{id}/contar', [ConferenciaController::class, 'contar'])->name('setores.conferencia.contar');


Route::post('/setores/conferencia/item/{id}/conferir', [ConferenciaController::class, 'contar'])->name('setores.conferencia.contar');



Route::middleware(['auth'])->group(function () {
    Route::post('/setores/conferencia/{id}/contar', [ConferenciaController::class, 'contar'])->name('setores.conferencia.contar');
});
