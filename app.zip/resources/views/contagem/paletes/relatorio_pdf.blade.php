<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Relatório de Contagem de Paletes</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        .header, .footer { text-align: center; }
        .header img { max-height: 50px; margin-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <img src="{{ public_path('logo.png') }}" alt="Logo">
        <h2>Relatório de Contagem de Paletes</h2>
        <p>Gerado em {{ \Carbon\Carbon::now()->format('d/m/Y H:i') }}</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo de Palete</th>
                <th>Quantidade</th>
                <th>Responsável</th>
                <th>Data</th>
            </tr>
        </thead>
        <tbody>
            @foreach($contagens as $item)
                <tr>
                    <td>{{ $item->id }}</td>
                    <td>{{ $item->tipo_palete }}</td>
                    <td>{{ $item->quantidade }}</td>
                    <td>{{ $item->usuario->nome ?? 'N/A' }}</td>
                    <td>{{ \Carbon\Carbon::parse($item->data_contagem)->format('d/m/Y H:i') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="footer">
        <p>Responsável: {{ auth()->user()->nome }}</p>
    </div>
</body>
</html>
