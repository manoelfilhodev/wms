@extends($layout)

@section('title', 'Nova Contagem de Paletes')

@section('content')
<div class="container">
    <h4 class="mb-4">➕ Nova Contagem de Paletes</h4>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>⚠️ {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('contagem.paletes.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label for="tipo_palete" class="form-label">Tipo de Palete</label>
            <input type="text" class="form-control" id="tipo_palete" name="tipo_palete" value="{{ old('tipo_palete') }}" required>
        </div>

        <div class="mb-3">
            <label for="quantidade" class="form-label">Quantidade</label>
            <input type="number" class="form-control" id="quantidade" name="quantidade" min="1" value="{{ old('quantidade') }}" required>
        </div>

        <div class="d-flex justify-content-between">
            <a href="{{ route('contagem.paletes.index') }}" class="btn btn-secondary">
                <i class="uil uil-arrow-left"></i> Voltar
            </a>
            <button type="submit" class="btn btn-success">
                <i class="uil uil-save"></i> Salvar Contagem
            </button>
        </div>
    </form>
</div>
@endsection
