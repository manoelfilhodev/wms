<div class="leftside-menu">
    <div class="h-100" data-simplebar>
        <div class="leftside-menu-container">
            <ul class="side-nav">
                <li class="side-nav-title">Navegação</li>

                <li class="side-nav-item">
                    <a href="{{ route('dashboard') }}" class="side-nav-link">
                        <i class="uil-home-alt"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                @php
                $nivel = strtolower(session('tipo', ''));
                @endphp

                @if($nivel === 'admin' || $nivel === 'gestor')
                <ul class="side-nav">

                    <li class="side-nav-item">
                        <a href="{{ route('setores.recebimento.painel') }}" class="side-nav-link">
                            <i class="mdi mdi-truck-delivery-outline"></i>
                            <span> Recebimento </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
    <a href="{{ route('etiquetas.html') }}" class="side-nav-link">
        <i class="uil uil-print"></i>
        <span> Etiquetas de Expedição </span>
    </a>
</li>


                    <li class="side-nav-item">
                        <a href="{{ route('armazenagem.index') }}" class="side-nav-link">
                            <i class="mdi mdi-warehouse"></i>
                            <span> Armazenagem </span>
                        </a>
                    </li>

                    <li class="side-nav-item">
                        <a href="{{ route('separacao.index') }}" class="side-nav-link">
                            <i class="mdi mdi-format-list-bulleted-square"></i>
                            <span> Separação </span>
                        </a>
                    </li>

                    <li class="side-nav-item">
                        <a href="#" class="side-nav-link">
                            <i class="mdi mdi-truck-fast-outline"></i>
                            <span> Expedição </span>
                        </a>
                    </li>

                    <li class="side-nav-item">
                        <a href="#" class="side-nav-link">
                            <i class="mdi mdi-clipboard-text-outline"></i>
                            <span> Controle de Estoque </span>
                        </a>
                    </li>
                    
                    <li class="side-nav-item">
                        <a href="{{ route('contagem.paletes.index') }}" class="side-nav-link">
                            <i class="uil uil-box"></i>
                            <span> Contagem de Paletes </span>
                        </a>
                    </li>


                    <li class="side-nav-item">
                        <a href="{{ route('usuarios.index') }}"
                            class="side-nav-link">
                            <i class="mdi mdi-account-group-outline"></i>
                            <span> Usuários </span>
                        </a>
                    </li>
                     <li class="side-nav-item">
                        <a href="{{ route('logs.index') }}" class="side-nav-link">
                            <i class="mdi mdi-history"></i>
                            <span> Logs de Usuário </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="{{ route('relatorios.index') }}" class="side-nav-link">
                            <i class="mdi mdi-chart-bar"></i>
                            <span> Relatórios</span>
                        </a>
                    </li>


                    <li class="side-nav-item">
                        <a href="#" class="side-nav-link">
                            <i class="mdi mdi-cog-outline"></i>
                            <span> Configurações </span>
                        </a>
                    </li>
                </ul>

                @endif
            </ul>
            @if($nivel === 'operador')
                <ul class="side-nav">                 

                    <li class="side-nav-item">
                        <a href="{{ route('armazenagem.index') }}" class="side-nav-link">
                            <i class="mdi mdi-warehouse"></i>
                            <span> Armazenagem </span>
                        </a>
                    </li>

                    <li class="side-nav-item">
                        <a href="{{ route('separacao.index') }}" class="side-nav-link">
                            <i class="mdi mdi-format-list-bulleted-square"></i>
                            <span> Separação </span>
                        </a>
                    </li>
                    <li class="side-nav-item">
                        <a href="{{ route('contagem.paletes.index') }}" class="side-nav-link">
                            <i class="uil uil-box"></i>
                            <span> Contagem de Paletes </span>
                        </a>
                    </li>
                </ul>

                @endif
            </ul>
        </div>
    </div>
</div>
