<div class="navbar-custom">
    <ul class="list-unstyled topbar-menu float-end mb-0">
        <li class="dropdown">
            <a class="nav-link dropdown-toggle nav-user me-0" data-bs-toggle="dropdown" href="#" role="button">
                <span class="d-none d-md-inline-block ms-1 fw-semibold">{{ session('nome') }}</span><br>
                <small class="d-none d-md-inline-block ms-1"> {{ session('tipo') }} </small>
            </a>
            <div class="dropdown-menu dropdown-menu-end">
                <a href="{{ route('logout') }}" class="dropdown-item"><i class="mdi mdi-logout"></i> Sair</a>
            </div>
        </li>
    </ul>
    <button class="button-menu-mobile open-left">
        <i class="mdi mdi-menu"></i>
    </button>
</div>
