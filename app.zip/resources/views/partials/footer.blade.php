<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © {{ date('Y') }} SYSTEX - Todos os direitos reservados.
            </div>
        </div>
    </div>
</footer>