@extends($layout)

@section('content')
<div class="container">
    <h4>Painel de Recebimento - Notas Fiscais</h4>

    <a href="{{ route('setores.recebimento.create') }}" class="btn btn-primary mb-3">Iniciar Recebimento</a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Iniciar</th>
                <th>NF</th>
                <th>Fornecedor</th>
                <th>Data</th>
                <th>Status</th>
                <th>Progresso</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
        @foreach($recebimentos as $recebimento)
            @php
                $totalItens = $recebimento->itens->count();
                $armazenados = $recebimento->itens->where('status', 'armazenado')->count();
                $percentual = $totalItens > 0 ? round(($armazenados / $totalItens) * 100) : 0;

                $temDivergencia = DB::table('_tb_recebimento_itens')
                    ->where('recebimento_id', $recebimento->id)
                    ->where('divergente', 1)
                    ->exists();

                $temAvaria = DB::table('_tb_recebimento_itens')
                    ->where('recebimento_id', $recebimento->id)
                    ->where('avariado', 1)
                    ->exists();

                $itensTotal = $recebimento->itens->count();
                $itensConferidos = $recebimento->itens->where('status', 'conferido')->count();
                $userTipo = Auth::user()->tipo ?? 'operador';
                $nivel = strtolower(Auth::user()->nivel);
            @endphp
            <tr>
                <td>
             
                        <span class="text-success">✔</span>
                   
                </td>
                <td>{{ $recebimento->nota_fiscal }}</td>
                <td>{{ $recebimento->fornecedor }}</td>
                <td>{{ \Carbon\Carbon::parse($recebimento->data_recebimento)->format('d/m/Y') }}</td>
                <td>
                    @if ($temDivergencia)
                        <span class="badge bg-danger">Divergência</span>
                    @endif

                    @if ($temAvaria)
                        <span class="badge bg-warning text-dark">Avaria</span>
                    @endif
                </td>
                <td>
                    <div class="progress">
                        <div class="progress-bar bg-{{ $percentual == 100 ? 'success' : ($percentual > 0 ? 'info' : 'secondary') }}" style="width: {{ $percentual }}%;">
                            {{ $percentual }}%
                        </div>
                    </div>
                </td>
                <td>
                    @if($itensConferidos === 0 && in_array($userTipo, ['admin', 'conferente']))
                        <a href="{{ route('setores.conferencia.telaFotoInicio', $recebimento->id) }}" class="btn btn-primary btn-sm">
                            Iniciar Conferência
                        </a>
                    @endif

                    @if($recebimento->status === 'conferido' && in_array($nivel, ['admin', 'documental', 'recebimento']))
                        <a href="{{ route('setores.conferencia.formRessalva', $recebimento->id) }}" class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-chat-left-dots"></i> Adicionar Ressalva
                        </a>
                    @endif

                    @if($recebimento->status === 'conferido' && in_array($nivel, ['admin', 'documental', 'recebimento']))
                        <a href="{{ route('setores.conferencia.relatorio', $recebimento->id) }}" target="_blank" class="btn btn-sm btn-outline-dark">
                            <i class="bi bi-file-earmark-pdf"></i> PDF
                        </a>
                    @endif
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection
