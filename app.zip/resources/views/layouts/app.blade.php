@php
    $segments = Request::segments();
    $title = ucfirst(end($segments));
@endphp

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <title>@yield('title', $title) | WMS 4.0</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Sistema WMS" name="description" />
    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico') }}">

    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets/css/app-creative.min.css') }}" rel="stylesheet" type="text/css" id="light-style" />
    <link href="{{ asset('assets/css/app-creative-dark.min.css') }}" rel="stylesheet" type="text/css" id="dark-style" />

    <style>
        .content::before {
            content: none !important;
        }

        .content > svg {
            display: none !important;
        }

        .sidebar-toggle, .vertical-menu-toggle, .menu-toggle {
            display: none !important;
        }

        .top-bar-operador {
            background-color: #111827;
            padding: 0.75rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar-operador span {
            color: #fff;
            font-weight: bold;
        }

        .top-bar-operador .btn {
            font-size: 0.9rem;
        }
    </style>

    @yield('head')
</head>

<body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false,"leftSidebarCondensed":false,"darkMode":false}'>

    <div class="wrapper">

        @auth
            @if(Auth::user()->tipo !== 'operador')
                @include('partials.sidebar')
            @endif
        @endauth

        <div class="content-page">
            <div class="content">

                @auth
                    @if(Auth::user()->tipo !== 'operador')
                        @include('partials.header')
                    @else
                        {{-- Topo simples para operadores --}}
                        <div class="top-bar-operador">
                            <span>Systex WMS</span>
                            <a href="{{ route('painel.operador') }}" class="btn btn-outline-light btn-sm">
                                <i class="bi bi-arrow-left"></i> Voltar ao Início
                            </a>
                        </div>
                    @endif
                @endauth

                <div class="container-fluid mt-3">
                    @yield('content')
                </div>
            </div>

            @include('partials.footer')
        </div>
    </div>

    <script src="{{ asset('assets/js/vendor.min.js') }}"></script>
    <script src="{{ asset('assets/js/app.min.js') }}"></script>
    @yield('scripts')

</body>
</html>
