<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $table = '_tb_usuarios';
    protected $primaryKey = 'id_user';
    public $timestamps = false;

    protected $fillable = ['nome', 'email', 'password', 'unidade_id', 'tipo', 'status', 'cod_nivel'];
    protected $hidden = ['password'];
}
