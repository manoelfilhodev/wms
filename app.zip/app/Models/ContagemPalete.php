<?php
// app/Models/ContagemPalete.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContagemPalete extends Model
{
    use HasFactory;

    protected $table = '_tb_contagem_paletes';

    protected $fillable = [
        'tipo_palete',
        'quantidade',
        'usuario_id',
        'data_contagem',
    ];

    public function usuario()
    {
        return $this->belongsTo(User::class, 'usuario_id');
    }
}
