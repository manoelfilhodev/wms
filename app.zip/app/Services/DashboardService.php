<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardService
{
    public function getTotaisGerais(): array
    {
        return [
            'posicoes' => DB::table('_tb_posicoes')->count(),
            'produtos' => DB::table('_tb_materiais')->count(),
            'usuarios' => DB::table('_tb_usuarios')->count(),
        ];
    }

    public function getContagensDoDia(Carbon $data): array
    {
        return [
            'armazenagem' => DB::table('_tb_armazenagem')->whereDate('data_armazenagem', $data)->count(),
            'separacao' => DB::table('_tb_separacoes')->whereDate('data_separacao', $data)->count(),
            'recebimento' => DB::table('_tb_recebimento')->whereDate('data_recebimento', $data)->count(),
            'expedicao' => DB::table('_tb_expedicao')->whereDate('data_expedicao', $data)->count(),
            'paletes' => DB::table('_tb_contagem_paletes')->whereDate('data_contagem', $data)->sum('quantidade'),
        ];
    }

    public function getVolumePorSetor(Carbon $data): array
    {
        return [
            'recebimento' => DB::table('_tb_recebimento')->whereDate('data_recebimento', $data)->count(),
            'armazenagem' => DB::table('_tb_armazenagem')->whereDate('data_armazenagem', $data)->count(),
            'separacao' => DB::table('_tb_separacoes')->whereDate('data_separacao', $data)->count(),
            'expedicao' => DB::table('_tb_expedicao')->whereDate('data_expedicao', $data)->count(),
        ];
    }

    public function getVolume7Dias(): array
    {
        $ultimos7Dias = [];

        for ($i = 6; $i >= 0; $i--) {
            $dia = Carbon::today()->subDays($i);
            $ultimos7Dias[] = [
                'data' => $dia->format('Y-m-d'),
                'total' => DB::table('_tb_armazenagem')
                    ->whereDate('data_armazenagem', $dia)
                    ->count(),
            ];
        }

        return $ultimos7Dias;
    }

    public function getDadosMensaisPorDia(): array
    {
        $dias = [];
        $armazenagem = [];
        $separacao = [];
        $paletes = [];

        $inicioMes = Carbon::now()->startOfMonth();
        $hoje = Carbon::now();

        for ($data = $inicioMes->copy(); $data <= $hoje; $data->addDay()) {
            $label = $data->format('d');

            $dias[] = $label;
            $armazenagem[] = DB::table('_tb_armazenagem')->whereDate('data_armazenagem', $data)->count();
            $separacao[] = DB::table('_tb_separacoes')->whereDate('data_separacao', $data)->count();
            $paletes[] = DB::table('_tb_contagem_paletes')->whereDate('data_contagem', $data)->sum('quantidade');
        }

        return [
            'dias' => $dias,
            'armazenagem' => $armazenagem,
            'separacao' => $separacao,
            'paletes' => $paletes,
        ];
    }

    public function getNotificacoesPendentes(): array
    {
        return DB::table('_tb_notificacoes')
            ->where('status', 'pendente')
            ->orderByDesc('created_at')
            ->limit(5)
            ->get()
            ->toArray();
    }

    public function marcarNotificacaoComoLida(int $id): void
    {
        DB::table('_tb_notificacoes')
            ->where('id', $id)
            ->update(['status' => 'visualizada']);
    }

    public function getOcupacaoRelativaPorPosicao(): array
    {
        $totalPosicoes = DB::table('_tb_posicoes')->count();
        $capacidadePorPosicao = 15 * 25;
        $capacidadeTotal = $totalPosicoes * $capacidadePorPosicao;

        $ocupacoes = DB::table('_tb_saldo_estoque as s')
            ->join('_tb_posicoes as p', 's.posicao_id', '=', 'p.id')
            ->select('p.codigo_posicao', DB::raw('SUM(s.quantidade) as total'))
            ->groupBy('p.codigo_posicao')
            ->orderByDesc('total')
            ->take(6)
            ->get();

        $resultado = [];

        foreach ($ocupacoes as $linha) {
            $percentual = ($capacidadeTotal > 0) ? ($linha->total / $capacidadeTotal) * 100 : 0;
            $resultado[] = [
                'endereco' => $linha->codigo_posicao,
                'total' => $linha->total,
                'percentual' => round($percentual, 2),
            ];
        }

        usort($resultado, function ($a, $b) {
            return $b['percentual'] <=> $a['percentual'];
        });

        return array_slice($resultado, 0, 6);
    }

    public function getOcupacaoTotalDoCD(): float
    {
        $totalPosicoes = DB::table('_tb_posicoes')->count();
        $capacidadeTotal = $totalPosicoes * 15 * 25;
        $quantidadeAtual = DB::table('_tb_saldo_estoque')->sum('quantidade');

        return $capacidadeTotal > 0
            ? round(($quantidadeAtual / $capacidadeTotal) * 100, 2)
            : 0;
    }

    public function getRankingOperadores(): array
    {
        $hoje = Carbon::today();
        $inicio = $hoje->copy()->subDays(6);

        // Armazenagem
        $armazenagem = DB::table('_tb_armazenagem as a')
            ->join('_tb_usuarios as u', 'a.usuario_id', '=', 'u.id_user')
            ->select(DB::raw("CONCAT(UCASE(SUBSTRING_INDEX(u.nome, ' ', 1)), ' ', UCASE(SUBSTRING_INDEX(u.nome, ' ', -1))) as nome"), DB::raw('SUM(a.quantidade) as total'))
            ->whereBetween('a.data_armazenagem', [$inicio, $hoje])
            ->groupBy('u.nome')
            ->orderByDesc('total')
            ->limit(5)
            ->get()
            ->toArray();

        // Separação
        $separacao = DB::table('_tb_separacoes as s')
            ->join('_tb_usuarios as u', 's.usuario_id', '=', 'u.id_user')
            ->select(DB::raw("CONCAT(UCASE(SUBSTRING_INDEX(u.nome, ' ', 1)), ' ', UCASE(SUBSTRING_INDEX(u.nome, ' ', -1))) as nome"), DB::raw('SUM(s.quantidade) as total'))
            ->whereBetween('s.data_separacao', [$inicio, $hoje])
            ->groupBy('u.nome')
            ->orderByDesc('total')
            ->limit(5)
            ->get()
            ->toArray();

        return [
            'armazenagem' => $armazenagem,
            'separacao' => $separacao,
        ];
    }

    public function getResumoDoDia(): array
    {
        $hoje = Carbon::today();
        $resumo = [];

        $setores = [
            'armazenagem' => [
                'tabela' => '_tb_armazenagem',
                'data_campo' => 'data_armazenagem',
                'quantidade_campo' => 'quantidade',
            ],
            'separacao' => [
                'tabela' => '_tb_separacoes',
                'data_campo' => 'data_separacao',
                'quantidade_campo' => 'quantidade',
            ],
            'kit_montagem' => [
                'tabela' => '_tb_kit_montagem',
                'data_campo' => 'data_montagem',
                'quantidade_campo' => 'quantidade',
            ],
        ];

        foreach ($setores as $nome => $conf) {
            $quantidade = DB::table($conf['tabela'])
                ->whereDate($conf['data_campo'], $hoje)
                ->sum($conf['quantidade_campo']);

            $resumo[$nome] = $quantidade;
        }

        return $resumo;
    }
}
