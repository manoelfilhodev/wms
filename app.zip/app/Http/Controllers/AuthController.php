<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        $validator = \Illuminate\Support\Facades\Validator::make($request->all(), [
    'email' => 'required|email',
    'password' => 'required',
]);

        $email = $credentials['email'];
        $ip = $request->ip();
        $navegador = $request->header('User-Agent');

        $usuario = User::where('email', $email)->first();

        $logDataOK = [
            'usuario_id' => $usuario->id_user ?? null,
            'unidade_id' => $usuario->unidade_id ?? null,
            'acao' => 'login - sucesso',
            'dados' => json_encode(['email' => $email]),
            'ip_address' => $ip,
            'navegador' => $navegador,
            'created_at' => now()
        ];

        $logDataNOK = [
            'usuario_id' => $usuario->id_user ?? null,
            'unidade_id' => $usuario->unidade_id ?? null,
            'acao' => 'login - falhou',
            'dados' => json_encode(['email' => $email]),
            'ip_address' => $ip,
            'navegador' => $navegador,
            'created_at' => now()
        ];

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();

            // Armazenar dados na sessão
            session([
                'user_id'   => $usuario->id_user,
                'nome'      => $usuario->nome,
                'tipo'      => $usuario->tipo,
                'unidade'   => $usuario->unidade_id,
                'nivel'     => $usuario->cod_nivel
            ]);
            
            
            // Redirecionamento conforme tipo de usuário
            if ($usuario->tipo == 'operador') {
                return redirect()->route('painel.operador');
            }
            
            // dd($usuario->tipo);

            DB::table('_tb_user_logs')->insert($logDataOK);
            return redirect()->intended('/dashboard');
        }

        DB::table('_tb_user_logs')->insert($logDataNOK);
        return back()->with('error', 'Login ou senha inválido');
    }

    public function logout(Request $request)
{
    $user = Auth::user();

    DB::table('_tb_user_logs')->insert([
        'usuario_id' => $user->id_user,
        'unidade_id' => $user->unidade_id,
        'acao' => 'logout',
        'dados' => '[LOGOUT] - Usuário saiu manualmente do sistema.',
        'ip_address' => $request->ip(),
        'created_at' => now()
    ]);

    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    // Redireciona com mensagem
    return redirect()->route('login')->with('success', 'Você saiu do sistema com sucesso!');
}
}
