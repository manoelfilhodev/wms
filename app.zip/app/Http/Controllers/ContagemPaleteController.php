<?php
// app/Http/Controllers/ContagemPaleteController.php

namespace App\Http\Controllers;

use App\Models\ContagemPalete;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Exports\ContagemPaletesExport;
use Maatwebsite\Excel\Facades\Excel;


class ContagemPaleteController extends Controller
{
    public function index(Request $request)
    {
        $query = ContagemPalete::with('usuario');

        if ($request->filled('tipo_palete')) {
            $query->where('tipo_palete', 'like', '%' . $request->tipo_palete . '%');
        }

        if ($request->filled('data_inicio') && $request->filled('data_fim')) {
            $query->whereBetween('data_contagem', [$request->data_inicio, $request->data_fim]);
        }

        $contagens = $query->orderByDesc('data_contagem')->paginate(10);

        return view('contagem.paletes.index', compact('contagens'));
    }

    public function create()
    {
        return view('contagem.paletes.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'tipo_palete' => 'required|string|max:255',
            'quantidade' => 'required|integer|min:1',
        ]);

        ContagemPalete::create([
            'tipo_palete' => $request->tipo_palete,
            'quantidade' => $request->quantidade,
            'usuario_id' => Auth::id(),
        ]);

        return redirect()->route('contagem.paletes.index')->with('success', 'Contagem registrada com sucesso.');
    }
    
    // public function exportPaletesPDF(Request $request)
    // {
    //     $dados = $this->filtrarPaletes($request)->get();
    //     $filename = 'contagem_paletes_' . now()->format('Y-m-d_H-i') . '.pdf';
    //     $pdf = Pdf::loadView('relatorios.contagem_paletes_pdf', compact('dados'));
    //     return $pdf->download($filename);
    // }

    

    
    public function exportExcel()
    {
        return Excel::download(new ContagemPaletesExport, 'contagem_paletes.xlsx');
    }
    
}
