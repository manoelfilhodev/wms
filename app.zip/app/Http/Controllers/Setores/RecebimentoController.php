<?php

// app/Http/Controllers/Setores/RecebimentoController.php
namespace App\Http\Controllers\Setores;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Setores\Recebimento;
use App\Models\Setores\RecebimentoItem;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;


class RecebimentoController extends Controller
{
    
   
    public function index()
    {
        return view('setores.recebimento.conferencia');
    }

    public function conferir(Request $request)
    {
        // Aqui você pode salvar a conferência no banco
        // Exemplo:
        // Recebimento::create($request->all());

        return back()->with('success', 'Item conferido com sucesso!');
    }
    
   public function painel()
    {
        $recebimentos = Recebimento::with('itens')->orderBy('data_recebimento', 'desc')->get();
        return view('setores.recebimento.painel', compact('recebimentos'));
    }

    
    public function detalharPainel($id)
    {
        $recebimento = DB::table('_tb_recebimento')->find($id);
        $itens = DB::table('_tb_recebimento_itens')->where('recebimento_id', $id)->get();
    
        $itensTotal = $itens->count();
        $itensConferidos = $itens->where('status', 'conferido')->count();
        $userTipo = Auth::user()->tipo ?? 'operador';
    
        return view('setores.recebimento.painel_detalhado', compact(
            'recebimento', 'itens', 'itensTotal', 'itensConferidos', 'userTipo'
        ));
    }

    
    public function create()
    {
        return view('setores.recebimento.create');
    }
    
public function store(Request $request)
{
    $request->validate([
        'motorista' => 'required|string|max:100',
        'placa' => 'required|string|max:20',
        'tipo' => 'required|string|max:50',
        'horario_janela' => 'required',
        'horario_chegada' => 'required',
        'doca' => 'required|string|max:20',
        'xml_nfe' => 'required|file|mimes:xml|max:2048',
    ]);

    $xml = simplexml_load_file($request->file('xml_nfe')->getRealPath());

    $nf = (string)$xml->NFe->infNFe->ide->nNF;
    $fornecedor = (string)$xml->NFe->infNFe->emit->xNome;
    $transportadora = (string)$xml->NFe->infNFe->transp->transporta->xNome ?? 'TRANSPORTADORA DESCONHECIDA';

    $nomeXML = null;
    if ($request->hasFile('xml_nfe')) {
        $arquivo = $request->file('xml_nfe');
        $nomeXML = 'nfe_' . time() . '.' . $arquivo->getClientOriginalExtension();
        $arquivo->move(public_path('xml_nfe'), $nomeXML);
    }

    // SALVAR RECEBIMENTO
    $recebimentoId = DB::table('_tb_recebimento')->insertGetId([
        'unidade_id'         => Auth::user()->unidade_id ?? 1,
        'nota_fiscal'        => $nf,
        'fornecedor'         => $fornecedor,
        'data_recebimento'   => now()->toDateString(),
        'usuario_id'         => Auth::id(),
        'status'             => 'pendente',
        'transportadora'     => $transportadora,
        'motorista'          => $request->motorista,
        'placa'              => $request->placa,
        'tipo'               => $request->tipo,
        'horario_janela'     => $request->horario_janela,
        'horario_chegada'    => $request->horario_chegada,
        'doca'               => $request->doca,
        'xml_nfe'            => $nomeXML,
    ]);

    // SALVAR LOG DE INÍCIO
    DB::table('_tb_user_logs')->insert([
        'usuario_id' => Auth::id(),
        'unidade_id' => Auth::user()->unidade_id ?? 1,
        'acao' => 'Início de Recebimento Documental',
        'dados' => '[INÍCIO RECEBIMENTO] - ' . Auth::user()->nome .
                   ' iniciou o recebimento da NF ' . $nf .
                   ', tipo de carga: ' . $request->tipo .
                   ', motorista: ' . $request->motorista .
                   ', placa: ' . $request->placa .
                   ', doca: ' . $request->doca,
        'ip_address' => $request->ip(),
        'navegador' => $request->header('User-Agent'),
        'created_at' => now()
    ]);

    // SALVAR ITENS DA NF
    foreach ($xml->NFe->infNFe->det as $item) {
        DB::table('_tb_recebimento_itens')->insert([
            'recebimento_id' => $recebimentoId,
            'sku'            => (string)$item->prod->cProd,
            'descricao'      => (string)$item->prod->xProd,
            'quantidade'     => (float)$item->prod->qCom,
            'status'         => 'pendente',
            'usuario_id'     => Auth::id(),
            'unidade_id'     => Auth::user()->unidade_id ?? 1,
            'created_at'     => now()
        ]);
    }

    return redirect()->route('setores.recebimento.painel')->with('success', 'Recebimento salvo com sucesso!');
}


}