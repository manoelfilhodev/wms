<?php

namespace App\Http\Controllers\Setores;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Setores\Armazenagem;
use Illuminate\Support\Facades\Auth;

class ArmazenagemController extends Controller
{
    public function index()
    {
        return view('setores.armazenagem.index');
    }

    public function store(Request $request)
    {
        
        $sku = $request->input('sku');

        // Verifica se o produto existe
        $produtoExiste = \DB::table('_tb_materiais')->where('sku', $sku)->exists();
        
        if (!$produtoExiste) {
            return back()->with('error', 'Produto não encontrado no sistema.');
        }
        $request->validate([
            'sku' => 'required|string|max:100',
            'quantidade' => 'required|integer|min:1',
            'endereco' => 'required|string|max:50',
        ]);

        Armazenagem::create([
            'sku' => $request->sku,
            'quantidade' => $request->quantidade,
            'endereco' => $request->endereco,
            'observacoes' => $request->observacoes,
            'usuario_id' => Auth::id(),
            'unidade_id' => Auth::user()->unidade_id ?? 1,
        ]);
        
        \DB::table('_tb_user_logs')->insert([
            'usuario_id' => Auth::id(),
            'unidade_id' => Auth::user()->unidade_id ?? 1,
            'acao' => 'Movimentacao de Armazenagem',
            'dados' => '[ARMAZENAGEM] - ' . Auth::user()->nome .
                       ' realizou movimentacao do SKU ' . $sku .
                       ', quantidade ' . $request->quantidade .
                       ', no endereco ' . $request->endereco . '.',
            'ip_address' => request()->ip(),
            'navegador' => request()->header('User-Agent'),
            'created_at' => now()
        ]);

        return back()->with('success', 'Produto armazenado com sucesso!');
    }
    
    
    
    public function buscarSkus(Request $request)
{
    $term = $request->input('term');
    $skus = \DB::table('_tb_materiais') // ou o nome correto da sua tabela
        ->where('sku', 'LIKE', '%' . $term . '%')
        ->pluck('sku'); // ou pode trazer ['sku', 'descricao']

    return response()->json($skus);
}

public function buscarDescricao(Request $request)
{
    $sku = $request->input('sku');

    $produto = \DB::table('_tb_materiais')->where('sku', $sku)->first();

    if ($produto) {
        return response()->json([
            'descricao' => strtoupper($produto->descricao), // Força maiúsculas
        ]);
    }

    return response()->json([
        'descricao' => null
    ], 404);
}

public function buscarPosicoes(Request $request)
{
    $term = $request->input('term');

    $posicoes = \DB::table('_tb_posicoes')
        ->where('codigo_posicao', 'LIKE', '%' . $term . '%')
        ->where('status', 'ativa')
        ->pluck('codigo_posicao');

    return response()->json($posicoes);
}
}