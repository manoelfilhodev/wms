<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User;
use Exception;

class MicrosoftController extends Controller
{
    public function redirectToProvider()
    {
        return Socialite::driver('microsoft')->redirect();
    }

    public function handleProviderCallback()
    {
        try {
            $microsoftUser = Socialite::driver('microsoft')->user();

            $email = $microsoftUser->getEmail();
            $name = $microsoftUser->getName();
            $microsoftId = $microsoftUser->getId();

            $user = User::where('email', $email)->first();

            if (!$user) {
                $id_user = DB::table('_tb_usuarios')->insertGetId([
                    'nome'        => $name,
                    'email'       => $email,
                    'password'    => bcrypt(str()->random(16)),
                    'unidade_id'  => null,
                    'tipo'        => 'operador', // ou outro valor default
                    'status'      => 'ativo',
                    'created_at'  => now(),
                    'updated_at'  => now(),
                ]);
                
                $user = DB::table('_tb_usuarios')->where('id_user', $id_user)->first();
            }

            // Faz login
            Auth::login($user);

            // Popula manualmente a sessão conforme o login normal
           session([
                'usuario'     => $user->nome,
                'tipo'        => $user->tipo,
                'unidade_id'  => $user->unidade_id,
                'id_user'     => $user->id_user,
            ]);

            // Registra o log
           DB::table('_tb_user_logs')->insert([
                'usuario_id' => $user->id_user,
                'unidade_id' => $user->unidade_id,
                'acao'       => 'login - sucesso (Microsoft)',
                'dados'      => json_encode(['email' => $email, 'nome' => $name]),
                'ip_address' => request()->ip(),
                'navegador'  => request()->header('User-Agent'),
                'created_at' => now(),
            ]);

            return redirect()->route('dashboard');

        } catch (Exception $e) {
            return redirect('/login')->with('error', 'Erro ao autenticar com a Microsoft: ' . $e->getMessage());
        }
    }
}
