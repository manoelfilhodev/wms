<?php

namespace SocialiteProviders\Manager\Exception;

use Exception;

class MissingConfigException extends Exception {}
