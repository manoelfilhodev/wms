<?php

declare(strict_types=1);

namespace Intervention\Image\Exceptions;

class RuntimeException extends \RuntimeException
{
}
