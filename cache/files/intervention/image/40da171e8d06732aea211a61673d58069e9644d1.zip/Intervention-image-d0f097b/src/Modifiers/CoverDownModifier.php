<?php

declare(strict_types=1);

namespace Intervention\Image\Modifiers;

class CoverDownModifier extends CoverModifier
{
}
